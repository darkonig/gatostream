'''
Created on 09/12/2014

@author: dk
'''
import tkinter
from tkFileDialog import *

def openFile():
    print('')

window = tkinter.Tk()
window.geometry("600x400")
 
lbl = tkinter.Label(window, text ="URL")
lbl.grid(row=0, column=0)
 
txtUrl = tkinter.Entry(window)
txtUrl.grid(row=0, column=1)
 
lbl1 = tkinter.Label(window, text ="Saida")
lbl1.grid(row=1, column=0)
 
txtOut = tkinter.Entry(window)
txtOut.grid(row=1, column=1)
 
btnOutFile = tkinter.Button(window, text = "...", command=openFile)
btnOutFile.grid(row=1, column=2)
 
text = tkinter.Text(window)
text.insert(tkinter.INSERT, "Starting...")
text.grid(row=2, column=0, columnspan=3)

window.mainloop()

if __name__ == '__main__':
    pass