#!/usr/bin/python
# encoding: utf-8

import sys, getopt
import argparse
from gato.core.gato import Gato

def usage():
    return """
    Faz download os videos da eduk.com.br

    Para gravar o video:
        python gato -u <url> -o <arquivo saída>

    Depois de gravar:
        python gato -i <video> -o <arquivo saída>
    """

def start(argv):
	url = ''
	inputfile = ''
	outputfile = ''
	convert = False
	try:
		opts, args = getopt.getopt(argv,'hi:o:u:x:')
	except getopt.GetoptError:
		print (usage())
		sys.exit(2)

	for opt, arg in opts:
		if opt == '-h':
			print (usage())
			sys.exit()
		elif opt in ("-i"):
			inputfile = arg
			convert = True
		elif opt in ("-o", "-x"):
			outputfile = arg
		elif opt in ("-u"):
			url = arg

	m = Gato()
	if convert == True:
		if inputfile == '' and outputfile == '':
			print('Argumentos incorretos.\nDigite: gato -h')
			sys.exit(1)
		m.convert(inputfile, outputfile)
	else:
		if url == '' and outputfile == '':
			print('Argumentos incorretos.\nDigite: gato -h')
			sys.exit(1)
		m.startDownload(url, outputfile)

def main():
	parser = argparse.ArgumentParser(description='Faz download os videos da eduk.com.br')

	group = parser.add_argument_group('Para baixar o arquivo')
	group.add_argument('-u', type=str, help='URL da pagina da eduk')
	group.add_argument('-o', type=str, help='Arquivo de saída')

	group2 = parser.add_argument_group('Para converter o video baixado para mp4')
	group2.add_argument('-i', type=str, help='Arquivo de video para converção')
	group2.add_argument('-x', type=str, help='Arquivo de saída')

	args = parser.parse_args()

	start(sys.argv[1:])

#main()
if __name__ == '__main__':    
    main()