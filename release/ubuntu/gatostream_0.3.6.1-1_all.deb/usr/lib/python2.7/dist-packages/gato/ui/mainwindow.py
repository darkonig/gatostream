#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Created on 10/12/2014

@author: dk
'''
import wx
from gato.core.gato import Gato
from gato.core import common
import sys
import threading
import os
import time
from threading import Thread
from gato.ui.fixvideowindow import FixVideoWindow
import logging

# Define notification event for thread completion
EVT_OPEN_PLAYER_ID = wx.NewId()

def EVT_OPEN_PLAYER(win, func):
    """Define Result Event."""
    win.Connect(-1, -1, EVT_OPEN_PLAYER_ID, func)

class OpenPlayerEvent(wx.PyEvent):
    """Simple event to carry arbitrary result data."""
    def __init__(self, cmd):
        """Init Result Event."""
        wx.PyEvent.__init__(self)
        self.SetEventType(EVT_OPEN_PLAYER_ID)
        self.cmd = cmd

class OpenPlayerThread(Thread):
    """Test Worker Thread Class."""

    #----------------------------------------------------------------------
    def __init__(self, wxObject, playerPath, filePath):
        """Init Worker Thread Class."""
        Thread.__init__(self)
        self.wxObject = wxObject
        self.playerPath = playerPath
        self.filePath = filePath
        self.start()    # start the thread

    #----------------------------------------------------------------------
    def run(self):
        time.sleep(1)
        fileinfo = os.stat(self.filePath)
        if fileinfo.st_size < 1024:
            self._openPlayer()
            return

        osCommandExecute = ''
        if sys.platform.startswith('win'):
            #osCommandExecute = ['start', self.playerPath, args.output]
            osCommandExecute = '"{0}" "{1}"'.format(self.playerPath, self.filePath)
        elif sys.platform.startswith('linux'):
            #osCommandExecute = ['open', self.playerPath, args.output]
            osCommandExecute = 'open "{0}" "{1}"'.format(self.playerPath, self.filePath)
        else:
            #osCommandExecute = ['open', self.playerPath, '--args', args.output]
            osCommandExecute = 'open "{0}" --args "{1}"'.format(self.playerPath, self.filePath)

        wx.PostEvent(self.wxObject, OpenPlayerEvent(osCommandExecute))


class MainWindow(wx.Frame):
    def __init__(self, parent, args):
        super(MainWindow, self).__init__(parent, title='Gato Stream', size=(495, 410),
                                         style=wx.MINIMIZE_BOX | wx.CAPTION | wx.CLOSE_BOX)

        if args.debug:
            logging.basicConfig(filename='gato.log', filemode='w', level=logging.DEBUG)
            logging.debug('Stating debug mode')
        
        self.currentFile = None
        self.playerPath = None
        self.args = args

        self.InitUI(args)
        self.Centre()
        self.Show()


    def InitUI(self, args):
        menubar = wx.MenuBar()
        self.SetMenuBar(menubar)

        fileMenu = wx.Menu()
        menubar.Append(fileMenu, '&Arquivo')

        fitem = fileMenu.Append(wx.ID_NEW, 'Nova Janela', u'Nova Janela')
        self.Bind(wx.EVT_MENU, self.OnNewWindow, fitem)

        fitem = fileMenu.Append(wx.ID_EXIT, 'Encerrar', u'Encerrar aplicação')
        self.Bind(wx.EVT_MENU, self.OnQuit, fitem)

        toolMenu = wx.Menu()
        menubar.Append(toolMenu, '&Ferramentas')

        fitem = toolMenu.Append(wx.ID_ANY, u'Corrigir vídeos', u'Arruma vídeos gravados com problemas')
        self.Bind(wx.EVT_MENU, self.OnFixVideo, fitem)

        helpMenu = wx.Menu()
        menubar.Append(helpMenu, '&Ajuda')

        fitem = helpMenu.Append(wx.ID_ANY, u'Sobre...', u'Sobre o aplicativo')
        self.Bind(wx.EVT_MENU, self.OnAboutBox, fitem)


        mainSizer = wx.GridBagSizer(5, 5)

        panel = wx.Panel(self, -1)
        mainSizer.Add(panel, pos=(0,0), flag=wx.EXPAND|wx.BOTTOM, border=10)

        icon = wx.Icon(common.get_pixmap('icon.png'), wx.BITMAP_TYPE_ANY)
        self.SetIcon(icon)



        sizer = wx.GridBagSizer(5, 5)

        #text1 = wx.StaticText(panel, label="Streaming Saver")
        #sizer.Add(text1, pos=(0, 0), flag=wx.TOP|wx.LEFT|wx.BOTTOM, border=15)

        iconB = wx.StaticBitmap(panel, bitmap=wx.Bitmap(common.get_pixmap('icon_long.png')))
        sizer.Add(iconB, pos=(0, 0), span=(1,4), flag=wx.TOP|wx.ALIGN_CENTER, border=5)

        line = wx.StaticLine(panel)
        sizer.Add(line, pos=(1, 0), span=(1, 4), flag=wx.EXPAND|wx.BOTTOM, border=10)



        pnlURL = wx.Panel(panel)
        sizer.Add(pnlURL, pos=(2, 0), span=(1, 4), flag=wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, border=10)
        sizerURL = wx.GridBagSizer(5, 5)


        lblURL = wx.StaticText(pnlURL, label='URL')
        sizerURL.Add(lblURL, pos=(0, 0), flag=wx.LEFT)

        self.textURL = wx.TextCtrl(pnlURL)
        sizerURL.Add(self.textURL, pos=(0, 1), span=(1, 3), flag=wx.TOP|wx.EXPAND)
        if args.url != None:
            self.textURL.SetValue(args.url)


        lblOut = wx.StaticText(pnlURL, label=u'Saída')
        sizerURL.Add(lblOut, pos=(1, 0), flag=wx.LEFT)

        self.textOutput = wx.TextCtrl(pnlURL)
        sizerURL.Add(self.textOutput, pos=(1, 1), span=(1, 2), flag=wx.TOP|wx.EXPAND)
        if args.output != None:
            self.textOutput.SetValue(args.output)

        btnSelectFile = wx.Button(pnlURL, size=(30,-1), label='...')
        sizerURL.Add(btnSelectFile, pos=(1, 3), flag=wx.TOP|wx.RIGHT)
        btnSelectFile.Bind(wx.EVT_BUTTON, self.OnSelectFile)

        self.chkPlayVideo = wx.CheckBox(pnlURL, label='Iniciar player')
        sizerURL.Add(self.chkPlayVideo, pos=(2, 0), span=(1,2), flag=wx.LEFT|wx.EXPAND, border=10)

        pnlURL.SetSizer(sizerURL)
        sizerURL.AddGrowableCol(1)


        self.lstVideos = wx.ListCtrl(panel, size=(460, 140), style=wx.LC_REPORT | wx.SUNKEN_BORDER)
        self.lstVideos.InsertColumn(0, 'Nome', width=200)
        self.lstVideos.InsertColumn(1, 'Status', width=100)
        self.lstVideos.InsertColumn(2, 'Info', width=150)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.ListVideoClick, self.lstVideos)
        sizer.Add(self.lstVideos, pos=(3, 0), span=(1, 4), flag=wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, border=10)



        panelBtns = wx.Panel(panel)
        sizer.Add(panelBtns, pos=(4, 0), span=(1, 4), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=10)

        sizerBtns = wx.GridBagSizer(5, 5)

        self.statusLabel = wx.StaticText(panelBtns, label=u'Não iniciada a gravação')
        sizerBtns.Add(self.statusLabel, pos=(0, 0), flag=wx.TOP|wx.LEFT|wx.EXPAND)

        bmp = wx.Image(common.get_pixmap('con_none.png'), wx.BITMAP_TYPE_ANY)
        self.connectionLabel = wx.StaticBitmap(panelBtns, bitmap=wx.BitmapFromImage(bmp), size=(18, 18))
        self.connectionLabel.SetToolTip(wx.ToolTip('[Internet Status] Desconhecido'))
        sizerBtns.Add(self.connectionLabel, pos=(0, 1), flag=wx.TOP|wx.LEFT)

        self.btnFix = wx.Button(panelBtns, label='Gravar')
        self.btnFix.Bind(wx.EVT_BUTTON, self.StartRecord)
        sizerBtns.Add(self.btnFix, pos=(0, 2), flag=wx.ALIGN_BOTTOM|wx.ALIGN_RIGHT)

        sizerBtns.AddGrowableCol(0)
        panelBtns.SetSizer(sizerBtns)
        sizerBtns.Fit(self)

        sizer.AddGrowableCol(2)
        panel.SetSizer(sizer)
        sizer.Fit(self)

        self.SetSizer(mainSizer)
        mainSizer.Fit(self)

        # Create some controls
        '''try:
			self.mc = wx.media.MediaCtrl(panel, pos=(startPosX + 380, startPosY), style=wx.SIMPLE_BORDER)
		except NotImplementedError:
			self.Destroy()
			raise

		if not self.mc.Load(args.output):
			wx.MessageBox(u"Não foi possível reproduzir '%s': Formatdo não suportado" % args.output, "ERROR", wx.ICON_ERROR | wx.OK)
		else:
			self.mc.SetBestFittingSize()
			self.GetSizer().Layout()
			self.slider.SetRange(0, self.mc.Length())
			self.mc.Play()'''

        EVT_OPEN_PLAYER(self, self._openPlayerInThread)

        # Get Player Path
        self.playerPath = self._getPlayerConfig()
        if self.playerPath == None:
            osCommandExecute = ''
            if sys.platform.startswith('win'):
                osCommandExecute = ['Executable file', 'Executable File (*.exe)|*.exe']
            elif sys.platform.startswith('linux'):
                osCommandExecute = ['Executable file', 'Executable File (*.*)|*.*']
            else:
                osCommandExecute = ['Application', 'Application (*.app)|*.app']

            dial = wx.MessageDialog(None, u'Para que possa fazer download e reproduzir o vídeo primeiro selecione o um Player de Vídeo (que reproduza .MP4)',
                                    u'Selecione um player de vídeo', wx.OK | wx.ICON_INFORMATION)
            dial.ShowModal()

            openFileDialog = wx.FileDialog(self, osCommandExecute[0], "", "", osCommandExecute[1], wx.FD_OPEN)
            if openFileDialog.ShowModal() == wx.ID_CANCEL:
                self.chkPlayVideo.Enable(False)
                return

            self.playerPath = openFileDialog.GetPath()
            self._savePlayerConfig(self.playerPath)


    def OnSelectFile(self, event):
        saveFileDialog = wx.FileDialog(self, "Save MP4 file", "", "",
                                   "MP4 files (*.mp4)|*.mp4", wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)

        if saveFileDialog.ShowModal() == wx.ID_CANCEL:
            return

        self.textOutput.SetValue(saveFileDialog.GetPath())

    def StartRecord(self, event):
        if self.textURL.GetValue() == '' and self.textOutput.GetValue() == '':
            dial = wx.MessageDialog(None, u'Preencha a URL e Saída.', 'Error', wx.OK | wx.ICON_ERROR)
            dial.ShowModal()
            return

        self.btnFix.Enable(False)
        self.textOutput.Enable(False)
        self.textURL.Enable(False)

        try:
            t = threading.Thread(target=self._start, args = ())
            t.daemon = True
            t.start()
        except:
            print "Error: unable to start thread"

    def _start(self):
        gato = Gato()
        gato.SetMessageHandler(self.MsgHandler)
        gato.SetDownloadHandler(self.DownloadEvent)
        gato.SetNewFileHandler(self.NewFileEvent)
        gato.SetProgressHandler(self.DownloadProgressEvent)
        gato.SetNetworkHandler(self.NetworkEvent)

        gato.startDownload(self.textURL.GetValue(), self.textOutput.GetValue())


    def MsgHandler(self, eventType, msg):
        if eventType == Gato.MSG_INFO:
            logging.info(msg)
        else:
            logging.error(msg)
            
        self.statusLabel.SetLabelText(msg)

    def DownloadEvent(self, eventType, info):
        if eventType == Gato.DOWNLOAD_END:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Finalizado')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
        elif eventType == Gato.DOWNLOAD_ERROR:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Error')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
        else:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Baixando')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)

            if self.chkPlayVideo.IsChecked() and self.playerPath != None:
                '''try:
                    t = threading.Thread(target=self._openPlayer, args = ())
                    t.daemon = True
                    t.start()
                except:
                    print "Error: unable to start thread"'''
                print ('Abrindo: ' + self.lstVideos.GetItem(self.lstVideos.GetItemCount()-1, 0).GetText())
                OpenPlayerThread(self, self.playerPath, self.lstVideos.GetItem(self.lstVideos.GetItemCount()-1, 0).GetText())

    """def _openPlayer(self):
        time.sleep(1)
        fileinfo = os.stat(self.textOutput.GetValue())
        if fileinfo.st_size < 1024:
            self._openPlayer()
            return

        osCommandExecute = ''
        if sys.platform.startswith('win'):
            osCommandExecute = ['start', self.playerPath, args.output]
        elif sys.platform.startswith('linux'):
            osCommandExecute = ['open', self.playerPath, args.output]
        else:
            osCommandExecute = ['open', self.playerPath, '--args', args.output]

        x = ''
        for w in osCommandExecute:
            x += w + ' '

        wx.Process().Open(x)
        #subprocess.call(osCommandExecute)
        '''p = Popen(osCommandExecute, stdout= subprocess.PIPE)
        try:
            out, err = p.communicate()
        except (KeyboardInterrupt, SystemExit):
            self._printInfo ('Cancelando o donwload')
            return

        rc = p.returncode'''"""

    def ListVideoClick(self, event):
        print ('Abrindo: ' + event.GetText())
        if self.playerPath != None:
            OpenPlayerThread(self, self.playerPath, event.GetText())

    def _openPlayerInThread(self, event):
        wx.Process().Open(event.cmd)

    def _savePlayerConfig(self, playerPath):
        import appdirs
        from ConfigParser import SafeConfigParser
        appname = "Gato Stream"
        appauthor = "DK"
        dataDir = appdirs.user_data_dir(appname, appauthor)
        dataFile = dataDir + '/config.cfg'

        if not os.path.exists(dataDir):
            os.makedirs(dataDir)

        config = SafeConfigParser()
        config.read(dataFile)
        config.add_section('main')
        config.set('main', 'player_path', playerPath)

        with open(dataFile, 'w') as f:
            config.write(f)

    def _getPlayerConfig(self):
        import appdirs
        from ConfigParser import SafeConfigParser
        appname = "Gato Stream"
        appauthor = "DK"
        dataDir = appdirs.user_data_dir(appname, appauthor)
        dataFile = dataDir + '/config.cfg'

        try:
            config = SafeConfigParser()
            config.read(dataFile)
            return config.get('main', 'player_path')
        except:
            return None

    def NewFileEvent(self, filename):
        if self.currentFile == filename:
            return

        self.currentFile = filename
        index = self.lstVideos.InsertStringItem(sys.maxint, filename)
        self.lstVideos.SetStringItem(index, 1, 'Conectando')

    def DownloadProgressEvent(self, msg):
        #wx.CallAfter(
        # if the window is not closed
        if hasattr(self, 'lstVideos'):
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, msg)
        pass

    def NetworkEvent(self, networkStatus):
        #wx.CallAfter(
        if networkStatus == Gato.NETWORK_INTERNET_AVAILABLE:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Iniciando')
            bmp = wx.Image(common.get_pixmap('con_available.png'), wx.BITMAP_TYPE_ANY)
            self.connectionLabel.SetBitmap(wx.BitmapFromImage(bmp))
            self.connectionLabel.SetToolTip(wx.ToolTip('[Internet Status] Conectado'))
        else:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, u'Sem conexão')
            bmp = wx.Image(common.get_pixmap('con_unavailable.png'), wx.BITMAP_TYPE_ANY)
            self.connectionLabel.SetBitmap(wx.BitmapFromImage(bmp))
            self.connectionLabel.SetToolTip(wx.ToolTip(u'[Internet Status] Sem conexão'))
        pass

    #MENU ACTIONS

    def OnNewWindow(self, e):
        MainWindow(None, self.args)
        pass

    def OnQuit(self, event):
        d = wx.MessageDialog(None, u'Tem certeza que deseja fechar o aplicativo? Se sim o download será interrompido.',
                          u'Fechar e interromper download', wx.YES_NO | wx.ICON_QUESTION)
        if d.ShowModal() == wx.ID_NO:
            return False

        self.Close()
        return True

    def OnFixVideo(self, e):
        FixVideoWindow(self)

    def OnAboutBox(self, e):

        description = u"""Gato Stream faz download de streaming de vídeos e salva em arquivo.
Após a download alguns arquivos podem ficar corrompidos, então também há
corretor de vídeos (Fix Video) localizado em (Ferramentas > Corrigir Vídeos).

Locais suportados:
 * dailymotion.com/live
 * livestream.com
 * twitch.tv
 * ustream.tv
 * youtube.com
"""

        licence = """Copyright (c) 2014-2015, Caio Andrade
All rights reserved.
            
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
            
1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
            
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."""


        info = wx.AboutDialogInfo()

        info.SetIcon(wx.Icon(common.get_pixmap('icon.png'), wx.BITMAP_TYPE_PNG))
        info.SetName('Gato Stream')
        info.SetVersion('0.3.6.1')
        info.SetDescription(description)
        info.SetCopyright('(C) 2014 - 2015 Caio Andrade')
        info.SetWebSite('http://gato.feijaodecorda.com')
        info.SetLicence(licence)
        info.AddDeveloper('Caio Andrade')
        #info.AddDocWriter('Caio Andrade')
        info.AddArtist('Caio Andrade')
        #info.AddTranslator('Caio Andrade')

        wx.AboutBox(info)
