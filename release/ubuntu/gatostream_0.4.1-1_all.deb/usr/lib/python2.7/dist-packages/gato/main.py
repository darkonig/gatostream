#!/usr/bin/python
# encoding: utf-8
'''
Starts the console program

@author: dk
'''
import sys, getopt
import argparse
from gato.core.gato import Gato
import gettext
from gato.core import common

t = gettext.translation('gato', common.get_translations_path(), languages=['pt_BR'])
_ = t.ugettext

def usage():
    return _(u'gato_usage')
    """return
    Faz download os videos da eduk.com.br

    Para gravar o video:
        python gato -u <url> -o <arquivo saída>

    Depois de gravar:
        python gato -i <video> -o <arquivo saída>
    """

def start(argv):
	url = ''
	inputfile = ''
	outputfile = ''
	convert = False
	try:
		opts, args = getopt.getopt(argv,'hi:o:u:x:')
	except getopt.GetoptError:
		print (usage())
		sys.exit(2)

	for opt, arg in opts:
		if opt == '-h':
			print (usage())
			sys.exit()
		elif opt in ("-i"):
			inputfile = arg
			convert = True
		elif opt in ("-o", "-x"):
			outputfile = arg
		elif opt in ("-u"):
			url = arg

	m = Gato()
	if convert == True:
		if inputfile == '' and outputfile == '':
			print(_(u'incorect_args'))
			sys.exit(1)
		m.convert(inputfile, outputfile)
	else:
		if url == '' and outputfile == '':
			print(_(u'incorect_args'))
			sys.exit(1)
		m.startDownload(url, outputfile)

def main():
	parser = argparse.ArgumentParser(description=_(u'cmd_description'))#'Faz download os videos da eduk.com.br')
	
	group = parser.add_argument_group(_(u'cmd_to_down'))#'Para baixar o arquivo')
	group.add_argument('-u', type=str, help=_(u'cmd_page_url'))#'URL da pagina da eduk')
	group.add_argument('-o', type=str, help=_(u'cmd_file_output'))#'Arquivo de saída')
	
	group2 = parser.add_argument_group(_(u'cmd_convert_video'))#'Para converter o video baixado para mp4')
	group2.add_argument('-i', type=str, help=_(u'cmd_convert_in_file'))#'Arquivo de video para converção')
	group2.add_argument('-x', type=str, help=_(u'cmd_convert'))#'Arquivo de saída')

	start(sys.argv[1:])

#main()
if __name__ == '__main__':    
    main()