#!/usr/bin/python
# encoding: utf-8
'''
Starts the gui program

@author: dk
'''

import argparse
from gato.ui.mainwindow import MainWindow
import wx

import gettext
from gato.core import common

t = gettext.translation('gato', common.get_translations_path(), languages=['pt_BR'])
_ = t.ugettext

def main():	
	parser = argparse.ArgumentParser(description=_(u'cmd_description'))
	
	group = parser.add_argument_group(_(u'cmd_to_down'))#'Para baixar o arquivo')
	group.add_argument('-u', '--url', type=str, help=_(u'cmd_page_url'))#'URL da pagina da eduk')
	group.add_argument('-o', '--output', type=str, help=_(u'cmd_file_output'))#'Arquivo de saída')
	
	group.add_argument('-d', '--debug', help='Debug', action='store_true')
	
	args = parser.parse_args()
	
	app = wx.App()
	MainWindow(None, args)
	app.MainLoop()

if __name__ == '__main__':
    main()