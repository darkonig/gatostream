#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Main window of the GatoStream
Created on 10/12/2014

@author: dk
'''
import wx
from gato.core.gato import Gato
from gato.core import common
import sys
import threading
import os
import time
from threading import Thread
from gato.ui.fixvideowindow import FixVideoWindow
import logging
import gettext
import locale
from .. import config
from gato.config import getLang, OS_WINDOWS, OS_MAC
import urllib2
import webbrowser

# Set up message catalog access
t = gettext.translation('gato', common.get_translations_path(), languages=[config.getLang()])
_ = t.ugettext


# Define notification event for go to download page
EVT_GO_TO_DOWNLOAD_PAGE_ID = wx.NewId()

def EVT_GO_TO_DOWNLOAD_PAGE(win, func):
    """Define open url in browser event."""
    win.Connect(-1, -1, EVT_GO_TO_DOWNLOAD_PAGE_ID, func)

class OpenGoToDownloadPageEvent(wx.PyEvent):
    """Simple event to open url in browser"""
    def __init__(self):
        wx.PyEvent.__init__(self)
        self.SetEventType(EVT_GO_TO_DOWNLOAD_PAGE_ID)



# Define notification event to open a player
EVT_OPEN_PLAYER_ID = wx.NewId()

def EVT_OPEN_PLAYER(win, func):
    """Define open player event."""
    win.Connect(-1, -1, EVT_OPEN_PLAYER_ID, func)

class OpenPlayerEvent(wx.PyEvent):
    """Simple event to open the player"""
    def __init__(self, cmd):
        """Init Player Event."""
        wx.PyEvent.__init__(self)
        self.SetEventType(EVT_OPEN_PLAYER_ID)
        self.cmd = cmd

class OpenPlayerThread(Thread):
    """Thread that waits the download file to reach 1mb and send 
    a event to open the player"""

    def __init__(self, wxObject, playerPath, filePath):
        Thread.__init__(self)
        self.wxObject = wxObject
        self.playerPath = playerPath
        self.filePath = filePath
        self.start()    # start the thread

    def run(self):
        time.sleep(1)
        fileinfo = os.stat(self.filePath)
        if fileinfo.st_size < 1024:
            self._openPlayer()
            return

        osCommandExecute = ''
        if config.getOS() == config.OS_WINDOWS:
            #osCommandExecute = ['start', self.playerPath, args.output]
            osCommandExecute = '"{0}" "{1}"'.format(self.playerPath, 
                                                    self.filePath)
        elif config.getOS() == config.OS_MAC:
            #osCommandExecute = ['open', self.playerPath, '--args', args.output]
            osCommandExecute = 'open "{0}" --args "{1}"'.format(
                                        self.playerPath, self.filePath)
        else:
            #osCommandExecute = ['open', self.playerPath, args.output]
            osCommandExecute = 'open "{0}" "{1}"'.format(self.playerPath, 
                                                         self.filePath)

        wx.PostEvent(self.wxObject, OpenPlayerEvent(osCommandExecute))



class LangChooser(wx.Dialog):
    """" Dialog of the language chooser"""
    
    def __init__(self):
        wx.Dialog.__init__(self, None, title="GatoStream Languages", 
                           style=wx.CAPTION|wx.SYSTEM_MENU)

        # get user language
        locale.setlocale(locale.LC_ALL, '') # use user's preferred locale
        
        loc = locale.getlocale()
        slang = None
        if loc[0]:
            slang = loc[0]
        
        selectedLang = None
        
        #fill list of langs
        lstLang = []
        for l in config.LANGUAGES:
            if l == slang:
                selectedLang = config.LANGUAGES[l]
            lstLang.append(config.LANGUAGES[l])
                    
        if slang and selectedLang == None:
            # take first two characters of country code
            slang = slang[0:2]
            for l in config.LANGUAGES:
                if l == slang:
                    selectedLang = config.LANGUAGES[l]
        
        #set Default Language (config.DEFAULT_LANG)
        if selectedLang == None:
            for l in config.LANGUAGES:
                if l == config.DEFAULT_LANG:
                    selectedLang = config.LANGUAGES[l]

        self.txt = wx.StaticText(self, label='Please select your language:')
        self.cmbLang = wx.ComboBox(self, 
                                     choices=lstLang,
                                     value=selectedLang)
        okBtn = wx.Button(self, wx.ID_OK)
        self.cmbLang.SetValue(selectedLang)

        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(self.txt, 0, wx.ALL|wx.CENTER, 5)
        sizer.Add(self.cmbLang, 0, wx.ALL|wx.CENTER, 5)
        sizer.Add(okBtn, 0, wx.ALL|wx.CENTER, 5)
        self.SetSizer(sizer)
        sizer.Fit(self)
        
    def getSelectedLang(self):
        for l in config.LANGUAGES:
            if self.cmbLang.GetValue() == config.LANGUAGES[l]:
                return l
        return None


class MainWindow(wx.Frame):
    """" Main window of GatoStream """
    
    def __init__(self, parent, args):
        super(MainWindow, self).__init__(parent, title='Gato Stream', size=(495, 410),
                                         style=wx.MINIMIZE_BOX | wx.CAPTION | wx.CLOSE_BOX)
        
        # if first open 
        # asks to user choose their language
        if config._getConfig() == None:
            chooser = LangChooser()
            chooser.Centre()
            if chooser.ShowModal() == wx.ID_OK:
                global _
                print ('select user lang {0}'.format(chooser.getSelectedLang()))
                config.saveConfig(None, chooser.getSelectedLang())
                config.setLang(chooser.getSelectedLang())
                
                t = gettext.translation('gato', 'i18n', languages=[config.getLang()])
                _ = t.ugettext
                
            chooser.Destroy()
        
        if args.debug:
            logging.basicConfig(filename='gato.log', filemode='w', level=logging.DEBUG)
            logging.debug('Stating debug mode')
            
        # current downloading file
        self.currentFile = None
        
        # the path of the choosed player 
        self.playerPath = None
        
        self.args = args

        self.InitUI(args)
        
        # verify system updates
        try:
            t = threading.Thread(target=self.verifySystemUpdate, args = ())
            t.daemon = True
            t.start()
        except:
            print "Error: unable to start thread"
        
        self.Centre()
        self.Show()
    
    def InitUI(self, args):
        menubar = wx.MenuBar()
        self.SetMenuBar(menubar)

        fileMenu = wx.Menu()
        menubar.Append(fileMenu, _(u'menu_file'))

        fitem = fileMenu.Append(wx.ID_NEW, _(u'new_window'), _(u'new_window'))
        self.Bind(wx.EVT_MENU, self.OnNewWindow, fitem)

        fitem = fileMenu.Append(wx.ID_EXIT, _(u'quit'), _(u'quit_help')) #'Encerrar', 'Encerrar aplicação'
        self.Bind(wx.EVT_MENU, self.OnQuit, fitem)

        toolMenu = wx.Menu()
        menubar.Append(toolMenu, _(u'tools'))

        fitem = toolMenu.Append(wx.ID_ANY, _(u'video_fixer'), _(u'video_fixer_help')) # u'Corrigir vídeos', u'Arruma vídeos gravados com problemas')
        self.Bind(wx.EVT_MENU, self.OnFixVideo, fitem)

        helpMenu = wx.Menu()
        menubar.Append(helpMenu, _(u'help'))

        #helpMenu.Append(wx.ID_HELP, _(u'help'))
        
        langMenu = wx.Menu()
        helpMenu.AppendMenu(wx.ID_ANY, _(u'lang'), langMenu)
        
        for l in config.LANGUAGES:
            fitem = langMenu.AppendRadioItem(wx.ID_ANY, config.LANGUAGES[l], l)
            
            if config.getLang() == l:
                langMenu.Check(fitem.GetId(), True)
                wx._core.CommandEvent
            self.Bind(wx.EVT_MENU, lambda e: (config.saveConfig(self.playerPath, langMenu.FindItemById(e.GetId()).GetHelp() ), 
                                              wx.MessageDialog(None, _(u'msg_lang_change'),
                                                               _(u'msg_title_lang_change'), wx.OK | wx.ICON_INFORMATION).ShowModal()), fitem)

        fitem = helpMenu.Append(wx.ID_ABOUT, _(u'about'), _(u'about_help'))#u'Sobre...', u'Sobre o aplicativo')
        self.Bind(wx.EVT_MENU, self.OnAboutBox, fitem)

        mainSizer = wx.GridBagSizer(5, 5)

        panel = wx.Panel(self, -1)
        mainSizer.Add(panel, pos=(0,0), flag=wx.EXPAND|wx.BOTTOM, border=10)

        icon = wx.Icon(common.get_pixmap('icon.png'), wx.BITMAP_TYPE_ANY)
        self.SetIcon(icon)



        sizer = wx.GridBagSizer(5, 5)

        iconB = wx.StaticBitmap(panel, bitmap=wx.Bitmap(common.get_pixmap('icon_long.png')))
        sizer.Add(iconB, pos=(0, 0), span=(1,4), flag=wx.TOP|wx.ALIGN_CENTER, border=5)

        line = wx.StaticLine(panel)
        sizer.Add(line, pos=(1, 0), span=(1, 4), flag=wx.EXPAND|wx.BOTTOM, border=10)



        pnlURL = wx.Panel(panel)
        sizer.Add(pnlURL, pos=(2, 0), span=(1, 4), flag=wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, border=10)
        sizerURL = wx.GridBagSizer(5, 5)


        lblURL = wx.StaticText(pnlURL, label=_(u'url'))
        sizerURL.Add(lblURL, pos=(0, 0), flag=wx.LEFT)

        self.textURL = wx.TextCtrl(pnlURL)
        sizerURL.Add(self.textURL, pos=(0, 1), span=(1, 3), flag=wx.TOP|wx.EXPAND)
        if args.url != None:
            self.textURL.SetValue(args.url)


        lblOut = wx.StaticText(pnlURL, label=_(u'output'))
        sizerURL.Add(lblOut, pos=(1, 0), flag=wx.LEFT)

        self.textOutput = wx.TextCtrl(pnlURL)
        sizerURL.Add(self.textOutput, pos=(1, 1), span=(1, 2), flag=wx.TOP|wx.EXPAND)
        if args.output != None:
            self.textOutput.SetValue(args.output)

        btnSelectFile = wx.Button(pnlURL, size=(30,-1), label='...')
        sizerURL.Add(btnSelectFile, pos=(1, 3), flag=wx.TOP|wx.RIGHT)
        btnSelectFile.Bind(wx.EVT_BUTTON, self.OnSelectFile)

        self.chkPlayVideo = wx.CheckBox(pnlURL, label=_(u'start_player'))
        sizerURL.Add(self.chkPlayVideo, pos=(2, 0), span=(1,2), flag=wx.LEFT|wx.EXPAND, border=10)

        pnlURL.SetSizer(sizerURL)
        sizerURL.AddGrowableCol(1)


        self.lstVideos = wx.ListCtrl(panel, size=(460, 140), style=wx.LC_REPORT | wx.SUNKEN_BORDER)
        self.lstVideos.InsertColumn(0, _(u'list_filename'), width=200)
        self.lstVideos.InsertColumn(1, _(u'list_status'), width=100)
        self.lstVideos.InsertColumn(2, _(u'list_info'), width=150)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.ListVideoClick, self.lstVideos)
        sizer.Add(self.lstVideos, pos=(3, 0), span=(1, 4), flag=wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, border=10)



        panelBtns = wx.Panel(panel)
        sizer.Add(panelBtns, pos=(4, 0), span=(1, 4), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=10)

        sizerBtns = wx.GridBagSizer(5, 5)

        self.statusLabel = wx.StaticText(panelBtns, label=_(u'record_not_started'))#u'Não iniciada a gravação')
        sizerBtns.Add(self.statusLabel, pos=(0, 0), flag=wx.TOP|wx.LEFT|wx.EXPAND)

        bmp = wx.Image(common.get_pixmap('con_none.png'), wx.BITMAP_TYPE_ANY)
        self.connectionLabel = wx.StaticBitmap(panelBtns, bitmap=wx.BitmapFromImage(bmp), size=(18, 18))
        self.connectionLabel.SetToolTip(wx.ToolTip(_(u'internet_status_unknown'))) #'[Internet Status] Desconhecido'
        sizerBtns.Add(self.connectionLabel, pos=(0, 1), flag=wx.TOP|wx.LEFT)

        self.btnFix = wx.Button(panelBtns, label=_(u'btn_record'))
        self.btnFix.Bind(wx.EVT_BUTTON, self.StartRecord)
        sizerBtns.Add(self.btnFix, pos=(0, 2), flag=wx.ALIGN_BOTTOM|wx.ALIGN_RIGHT)

        sizerBtns.AddGrowableCol(0)
        panelBtns.SetSizer(sizerBtns)
        sizerBtns.Fit(self)

        sizer.AddGrowableCol(2)
        panel.SetSizer(sizer)
        sizer.Fit(self)

        self.SetSizer(mainSizer)
        mainSizer.Fit(self)

        # Create some controls
        '''try:
			self.mc = wx.media.MediaCtrl(panel, pos=(startPosX + 380, startPosY), style=wx.SIMPLE_BORDER)
		except NotImplementedError:
			self.Destroy()
			raise

		if not self.mc.Load(args.output):
			wx.MessageBox(u"Não foi possível reproduzir '%s': Formatdo não suportado" % args.output, "ERROR", wx.ICON_ERROR | wx.OK)
		else:
			self.mc.SetBestFittingSize()
			self.GetSizer().Layout()
			self.slider.SetRange(0, self.mc.Length())
			self.mc.Play()'''

        EVT_OPEN_PLAYER(self, self._openPlayerInThread)
        EVT_GO_TO_DOWNLOAD_PAGE(self, self._updateAskDialog)

        # Get Player Path
        self.playerPath = config.getPlayerPath()
        if self.playerPath == None:
            osCommandExecute = ''
            if config.getOS() == config.OS_WINDOWS:
                osCommandExecute = ['Executable file', 'Executable File (*.exe)|*.exe']
            elif config.getOS() == config.OS_MAC:
                osCommandExecute = ['Application', 'Application (*.app)|*.app']
            else:
                osCommandExecute = ['Executable file', 'Executable File (*.*)|*.*']

            dial = wx.MessageDialog(None, _(u'msg_select_video_player'), #u'Para que possa fazer download e reproduzir o vídeo primeiro selecione o um Player de Vídeo (que reproduza .MP4)',
                                    _(u'msg_title_select_video_player'), #u'Selecione um player de vídeo', 
                                    wx.OK | wx.ICON_INFORMATION)
            dial.ShowModal()

            openFileDialog = wx.FileDialog(self, osCommandExecute[0], "", "", osCommandExecute[1], wx.FD_OPEN)
            if openFileDialog.ShowModal() == wx.ID_CANCEL:
                self.chkPlayVideo.Enable(False)
                return

            self.playerPath = openFileDialog.GetPath()
            config.saveConfig(self.playerPath, getLang())

    def verifySystemUpdate(self):
        """ Verifies the system updates using the config.SYSTEM_UPDATE_VERIFY_URL """
        try:
            url = config.SYSTEM_UPDATE_VERIFY_URL
            if config.getOS() == OS_WINDOWS:
                url += 'win'
            elif config.getOS() == OS_MAC:
                url += 'mac'
            else:
                url += 'ubuntu'
            
            url += '/VERSION'
            req = urllib2.Request(url)
            
            # reads the file and get the version
            for line in urllib2.urlopen(req):
                if line.strip() != config.SYSTEM_VERSION:
                    wx.PostEvent(self, OpenGoToDownloadPageEvent())
                    
        except Exception as e:
            print e
            pass

    def _updateAskDialog(self, e):
        """ Asks if user wants to update the app """
        dial = wx.MessageDialog(self, u'{0} ({1})'.format(_(u'msg_system_update'), config.SYSTEM_UPDATE_URL),
                         _(u'msg_title_system_update'),
                         wx.YES_NO | wx.ICON_QUESTION)
        if dial.ShowModal() == wx.ID_YES:                        
            webbrowser.open(config.SYSTEM_UPDATE_URL, autoraise=True)
        dial.Destroy()

    def OnSelectFile(self, event):
        """ Asks to user select their player """
        saveFileDialog = wx.FileDialog(self, "Save MP4 file", "", "",
                                   "MP4 files (*.mp4)|*.mp4", wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)

        if saveFileDialog.ShowModal() == wx.ID_CANCEL:
            return

        self.textOutput.SetValue(saveFileDialog.GetPath())

    def StartRecord(self, event):
        """ Records the requested URL """
        # verify if the URL field and output field is filled
        if self.textURL.GetValue() == '' and self.textOutput.GetValue() == '':
            dial = wx.MessageDialog(None, _(u'error_fill_url_output'), 'Error', wx.OK | wx.ICON_ERROR) #u'Preencha a URL e Saída.'
            dial.ShowModal()
            return

        self.btnFix.Enable(False)
        self.textOutput.Enable(False)
        self.textURL.Enable(False)

        # starts the download thread
        try:
            t = threading.Thread(target=self._start, args = ())
            t.daemon = True
            t.start()
        except:
            print "Error: unable to start thread"

    def _start(self):
        """ Records the URL stream """
        gato = Gato()
        gato.SetMessageHandler(self.MsgHandler)
        gato.SetDownloadHandler(self.DownloadEvent)
        gato.SetNewFileHandler(self.NewFileEvent)
        gato.SetProgressHandler(self.DownloadProgressEvent)
        gato.SetNetworkHandler(self.NetworkEvent)

        gato.startDownload(self.textURL.GetValue(), self.textOutput.GetValue())


    def MsgHandler(self, eventType, msg):
        """ Message Handler """
        if eventType == Gato.MSG_INFO:
            logging.info(msg)
        else:
            logging.error(msg)
            
        self.statusLabel.SetLabelText(msg)

    def DownloadEvent(self, eventType, info):
        """ Fired when on download """
        if eventType == Gato.DOWNLOAD_END:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, _(u'down_status_ended'))#'Finalizado')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
        elif eventType == Gato.DOWNLOAD_ERROR:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, _(u'down_status_error')) #Erro
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
        else:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, _(u'down_status_downloading')) #Baixando
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
            
            if self.chkPlayVideo.IsChecked() and self.playerPath != None:
                print ('Opening: ' + self.lstVideos.GetItem(self.lstVideos.GetItemCount()-1, 0).GetText())
                OpenPlayerThread(self, self.playerPath, self.lstVideos.GetItem(self.lstVideos.GetItemCount()-1, 0).GetText())

    def ListVideoClick(self, event):
        """ Opens the video clicked on the download list """
        print ('Opening: ' + event.GetText())
        if self.playerPath != None:
            OpenPlayerThread(self, self.playerPath, event.GetText())

    def _openPlayerInThread(self, event):
        """ Opens player """
        wx.Process().Open(event.cmd)

    def NewFileEvent(self, filename):
        """ Fired on starting the download """
        if self.currentFile == filename:
            return

        self.currentFile = filename
        index = self.lstVideos.InsertStringItem(sys.maxint, filename)
        self.lstVideos.SetStringItem(index, 1, _(u'down_status_connecting'))#'Conectando')

    def DownloadProgressEvent(self, msg):
        """ Download progress event """
        # if the window is not closed
        if hasattr(self, 'lstVideos'):
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, msg)
        pass

    def NetworkEvent(self, networkStatus):
        if networkStatus == Gato.NETWORK_INTERNET_AVAILABLE:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, _(u'down_status_starting'))#'Iniciando')
            bmp = wx.Image(common.get_pixmap('con_available.png'), wx.BITMAP_TYPE_ANY)
            self.connectionLabel.SetBitmap(wx.BitmapFromImage(bmp))
            self.connectionLabel.SetToolTip(wx.ToolTip(_(u'internet_status_connected')))#'[Internet Status] Conectado'))
        else:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, _(u'down_status_no_connection'))#u'Sem conexão')
            bmp = wx.Image(common.get_pixmap('con_unavailable.png'), wx.BITMAP_TYPE_ANY)
            self.connectionLabel.SetBitmap(wx.BitmapFromImage(bmp))
            self.connectionLabel.SetToolTip(wx.ToolTip(_(u'internet_status_no_connection')))#u'[Internet Status] Sem conexão'))
        pass



    #MENU ACTIONS

    def OnNewWindow(self, e):
        """ Opens a new window """
        MainWindow(None, self.args)
        pass

    def OnQuit(self, event):
        """ On closes """
        d = wx.MessageDialog(None, _(u'msg_quit_app'),#u'Tem certeza que deseja fechar o aplicativo? Se sim o download será interrompido.',
                          _(u'msg_title_quit_app'),#u'Fechar e interromper download', 
                          wx.YES_NO | wx.ICON_QUESTION)
        if d.ShowModal() == wx.ID_NO:
            return False

        self.Close()
        return True

    def OnFixVideo(self, e):
        """ Opens video fixer """
        FixVideoWindow(self)

    def OnAboutBox(self, e):
        """ Opens the about box """
        
        description = _(u"""about_description""")
        """description = u "" Gato Stream faz download de streaming de vídeos e salva em arquivo.
Após a download alguns arquivos podem ficar corrompidos, então também há
corretor de vídeos (Fix Video) localizado em (Ferramentas > Corrigir Vídeos).

Locais suportados:
 * dailymotion.com/live
 * livestream.com
 * twitch.tv
 * ustream.tv
 * youtube.com
"""

        licence = """Copyright (c) 2014-2015, Caio Andrade
All rights reserved.
            
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
            
1. Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
this list of conditions and the following disclaimer in the documentation
and/or other materials provided with the distribution.
            
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."""


        info = wx.AboutDialogInfo()

        info.SetIcon(wx.Icon(common.get_pixmap('icon.png'), wx.BITMAP_TYPE_PNG))
        info.SetName(config.SYSTEM_NAME)
        info.SetVersion(config.SYSTEM_VERSION)
        info.SetDescription(description)
        info.SetCopyright('(C) 2014 - 2015 Caio Andrade')
        info.SetWebSite('http://gato.feijaodecorda.com')
        info.SetLicence(licence)
        info.AddDeveloper('Caio Andrade')
        #info.AddDocWriter('Caio Andrade')
        info.AddArtist('Caio Andrade')
        #info.AddTranslator('Caio Andrade')

        wx.AboutBox(info)
