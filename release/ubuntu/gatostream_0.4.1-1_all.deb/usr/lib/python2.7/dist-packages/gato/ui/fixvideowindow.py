#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Video Fixer Window
Created on 14/12/2014

@author: dk
'''
import wx
import sys
import os
import subprocess
import threading
from gato.core import common
from Queue import Queue, Empty
import gettext
from .. import config

t = gettext.translation('gato', common.get_translations_path(), languages=[config.getLang()])
_ = t.ugettext

class FileDrop(wx.FileDropTarget):
    """ File drop event """
    def __init__(self, window):
        wx.FileDropTarget.__init__(self)
        self.window = window

    def OnDropFiles(self, x, y, filenames):
        for name in filenames:
            index = self.window.lstVideos.InsertStringItem(sys.maxint, name)
            self.window.lstVideos.SetStringItem(index, 2, _(u'fixer_status_pending'))#'Pendente')


class NonBlockingStreamReader:
    def __init__(self, stream):
        '''
        stream: the stream to read from.
                Usually a process' stdout or stderr.
        '''

        self._s = stream
        self._q = Queue()

        def _populateQueue(stream, queue):
            '''
            Collect lines from 'stream' and put them in 'quque'.
            '''
            while True:
                line = stream.readline()
                if line:
                    queue.put(line)

        self._t = threading.Thread(target = _populateQueue,
                args = (self._s, self._q))
        self._t.daemon = True
        self._t.start() #start collecting lines from the stream

    def readline(self, timeout = None):
        try:
            #return self._q.get(block = timeout is not None,
            #        timeout = timeout)
            return self._q.get_nowait()
        except Empty:
            return None

#class UnexpectedEndOfStream(Exception): pass



ON_POSIX = 'posix' in sys.builtin_module_names

class BashProcessThread(threading.Thread):
    """ Thread that process the files (fix files) and waits the process to finish """
    
    def __init__(self, cmd, lstVideos, logger):
        threading.Thread.__init__(self)
        self.cmd = cmd
        self.lstVideos = lstVideos
        self.logger = logger
        self.setDaemon(False)

    def run(self):
        for i in range(0, len(self.cmd)):
            print (u'======== Processing {0} ====='.format(self.lstVideos.GetItem(i,0).GetText()))

            wx.CallAfter(self.logger.AppendText, u'======== Processing {0} ====='.format(self.lstVideos.GetItem(i,0).GetText()))
            try:
                bp = subprocess.Popen(self.cmd[i], shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=1, close_fds=ON_POSIX)
                
                nbsr = NonBlockingStreamReader(bp.stdout)
                nbsrErr = NonBlockingStreamReader(bp.stderr)
                while bp.poll() is None:
                    output = nbsr.readline()
                    output2 = nbsrErr.readline()

                    if output:
                        print(output)
                        wx.CallAfter(self.logger.AppendText, output)

                    if output2:
                        print(output2,)
                        wx.CallAfter(self.logger.AppendText, output2)
                #ProcessReadThread(bp.stdout, self.logger).start()
                #ProcessReadThread(bp.stderr, self.logger).start()
                #bp.communicate()

                print 'return {0}'.format(bp.returncode)
                if bp.returncode == 0:
                    self.lstVideos.SetStringItem(i, 2, _(u'fixer_status_ended'))
                else:
                    self.lstVideos.SetStringItem(i, 2, _(u'fixer_status_error'))
            except:
                raise
                return


class FixVideoWindow(wx.Frame):
    """ Video Fixer Window """
    
    def __init__(self, parent):
        super(FixVideoWindow, self).__init__(parent, title='Video Fixer', size=(600, 490),
                                         style=wx.MINIMIZE_BOX | wx.CAPTION | wx.CLOSE_BOX)
        
        # sets the drop target to the window
        dt = FileDrop(self)
        self.SetDropTarget(dt)

        self.InitUI()
        self.Centre()
        self.Show()

    def InitUI(self):
        panel = wx.Panel(self, -1)

        sizer = wx.GridBagSizer(5, 5)

        text1 = wx.StaticText(panel, label="Video Fixer")
        sizer.Add(text1, pos=(0, 0), flag=wx.TOP|wx.LEFT|wx.BOTTOM, border=15)

        iconB = wx.StaticBitmap(panel, bitmap=wx.Bitmap(common.get_pixmap('icon.png')))
        sizer.Add(iconB, pos=(0, 3), flag=wx.TOP|wx.RIGHT|wx.ALIGN_RIGHT, border=5)

        line = wx.StaticLine(panel)
        sizer.Add(line, pos=(1, 0), span=(1, 4), flag=wx.EXPAND|wx.BOTTOM, border=10)

        lblOut = wx.StaticText(panel, label=_(u'fixer_files'))#u'Arquivos')
        sizer.Add(lblOut, pos=(2, 0), flag=wx.LEFT, border=10)

        self.lstVideos = wx.ListCtrl(panel, size=(580, 210), style=wx.LC_REPORT | wx.SUNKEN_BORDER)
        self.lstVideos.InsertColumn(0, _(u'fixer_filename'), width=250)
        self.lstVideos.InsertColumn(1, _(u'fixer_filename_output'), width=250)
        self.lstVideos.InsertColumn(2, _(u'fixer_file_status'), width=70)
        sizer.Add(self.lstVideos, pos=(3, 0), span=(1, 4), flag=wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, border=10)

        self.btnFix = wx.Button(panel, label='Corrigir')
        self.btnFix.Bind(wx.EVT_BUTTON, self.StartFixing)
        sizer.Add(self.btnFix, pos=(4, 3), flag=wx.TOP|wx.RIGHT|wx.ALIGN_RIGHT, border=10)

        self.logger = wx.TextCtrl(panel, -1, size=(-1,90), style = wx.TE_MULTILINE|wx.TE_READONLY)
        sizer.Add(self.logger, pos=(5, 0), span=(1, 4), flag=wx.EXPAND|wx.TOP|wx.LEFT|wx.RIGHT, border=10)
        
        #fill for test
        #index = self.lstVideos.InsertStringItem(sys.maxint, '/Users/dk/Documents/fotografecel.mp4')
        #index = self.lstVideos.InsertStringItem(sys.maxint, '/Users/dk/Documents/teste.mp4')
        #self.lstVideos.SetStringItem(index, 2, 'Pendente')

        panel.SetSizer(sizer)

    def StartFixing(self, e):
        """ Creates the fix command and starts the tread to fix the vídeos """
        cmds = []
        for i in range(0, self.lstVideos.GetItemCount()):
            filePath = self.lstVideos.GetItem(i, 0).GetText()
            fixFilePath = self.NewFixedName(filePath)

            osCommandExecute = ''
            if config.getOS() == config.OS_WINDOWS:
                osCommandExecute = ['ext/Win/avconv.exe', '-i', filePath, '-codec', 'copy', fixFilePath]
                #osCommandExecute = 'start "{0}" "{1}"'.format(self.playerPath, filePath, fixFilePath)
            elif config.getOS() == config.OS_MAC:
                osCommandExecute = ['ext/Mac/avconv', '-i', filePath, '-codec', 'copy', fixFilePath]
            else:
                osCommandExecute = ['avconv', '-i', filePath, '-codec', 'copy', fixFilePath]
                #osCommandExecute = 'open "{0}" "{1}"'.format(self.playerPath, filePath, fixFilePath)
            #wx.Process().Open('open ')
            cmds.append(osCommandExecute)
            self.lstVideos.SetStringItem(i, 1, fixFilePath)
            st = os.access(filePath, os.W_OK)
            print (st)
            if not st:
                d = wx.MessageDialog(None, u'{0} ("{1}")'.format(_(u'fixer_msg_no_write_permission'), filePath), #Erro você deve ter permissão de escrita em 
                                     'Erro', wx.OK_DEFAULT | wx.ICON_ERROR)
                d.ShowModal()
                return

        if len(cmds) > 0:
            self._call(cmds)


    def _call(self, cmds):
        """ Starts the file fixer thread """
        p = BashProcessThread(cmds, self.lstVideos, self.logger)
        p.start()

    def NewFixedName(self, output):
        """ Generate a name for the fixed video """
        
        counter = 0
        def _getName(output):
            i = output.rfind('.')
            if i > -1:
                if counter > 0:
                    return output[:i] + str(counter) + '.fixed' + output[i:]

                return output[:i] + '.fixed' + output[i:]
            else:
                return output + str(self.counter)

        nFile = _getName(output)
        while os.path.exists(nFile):
            counter += 1
            nFile = _getName(output)

        return nFile

if __name__ == '__main__':
    app = wx.App()
    FixVideoWindow(None)
    app.MainLoop()
