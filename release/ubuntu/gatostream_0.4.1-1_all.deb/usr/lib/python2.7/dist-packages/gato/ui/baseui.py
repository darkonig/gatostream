'''
Used only to get path at common.py

@author: dk
'''
