#!/usr/bin/python
# encoding: utf-8
from livestreamer.exceptions import *

import urllib2

from livestreamer import Livestreamer
from subprocess import call, PIPE, Popen
import sys, getopt
import lxml.html

#import signal
import time, random

from streamrecorder import StreamRecorder
import os

import gettext
from .. import config
from . import common

t = gettext.translation('gato', common.get_translations_path(), languages=[config.getLang()])
_ = t.ugettext

class SearchResultParser:
	def __init__(self, html):
		self.doc = lxml.html.parse(html).getroot()

	def parse(self):
		src = ''
		try:
			video = self.doc.xpath('//*[@id="live-video"]')[0]
			iframe = [item for item in video.iterchildren() if item.tag == 'iframe']
			src = iframe[0].attrib['src']
		except:
			raise BaseException(_(u'gato_page_interpretation_error'))#'############## Erro na interpretação ##################')
			pass
		return src

class Gato:
	MSG_INFO = 0
	MSG_ERROR = 1

	DOWNLOAD_START = 1
	DOWNLOAD_END = 2
	DOWNLOAD_ERROR = 3

	NETWORK_INTERNET_UNAVAILABLE = 1
	NETWORK_INTERNET_AVAILABLE = 2

	def __init__(self):
		self.counter = 0
		self.triedTimes = 1
		self.maxTryTimes = 5
		self.waitTime = 0
		self.url = ''
		self._signal_handle()

		self.msgHandler = None
		self.downloadHandler = None
		self.progressHandler = None
		self.newFileHandler = None
		self.networkHandler = None
		pass
	#not used
	def play(self, src):
		from livestreamerplayer import LivestreamerPlayer
		quality = 'best'
		livestreamer = Livestreamer()

		# Enable logging
		livestreamer.set_loglevel("info")
		livestreamer.set_logoutput(sys.stdout)

		# Attempt to find a plugin for this URL
		try:
			plugin = livestreamer.resolve_url(src)
		except NoPluginError:
			exit("Livestreamer is unable to handle the URL '{0}'".format(src))

		# Attempt to fetch streams
		try:
			streams = plugin.get_streams()
		except PluginError as err:
			exit("Plugin error: {0}".format(err))

		if len(streams) == 0:
			exit("No streams found on URL '{0}'".format(src))

		# Look for specified stream
		if quality not in streams:
			exit("Unable to find '{0}' stream on URL '{1}'".format(quality, src))

		# We found the stream
		stream = streams[quality]

		# Create the player and start playback
		player = LivestreamerPlayer()

		#out = FileOutput(fd=stdout)
		# Blocks until playback is done
		player.play(stream)

	def _signal_handle(self):
		#ignore CTRL+C (Interrupt)
		#signal.signal(signal.SIGINT, signal.SIG_IGN)
		print ('signal')

	def _download(self, src, output):
		'''#_download(['livestreamer', src, 'best', '-o', output])
		p = Popen(['livestreamer', src, 'best', '-o', output])
		try:
			out, err = p.communicate()
		except (KeyboardInterrupt, SystemExit):
			self._printInfo ('Cancelando o donwload')
			return

		rc = p.returncode
		self._printInfo('Download finalizado ({0})'.format(rc));
		if rc == 0:
			self.startDownload(self.url, output + str(self.counter))'''
		stream = StreamRecorder(src, output)
		stream.SetMessageHandler(self.msgHandler)
		stream.SetDownloadHandler(self._downloadEvent)
		stream.SetProgressHandler(self.progressHandler)
		try:
			if stream.saveStream():
				self._printInfo(u'gato_download_ended') #Download finalizado.

			self.startDownload(self.url, self._getNewFileName(output))
		except StreamError as err:
			self._printInfo ('Error: {0}'.format(err))
			self._fireDownloadCancel('Error: {0}'.format(err))

			self.startDownload(self.url, self._getNewFileName(output))
		except IOError as err:
			self._printInfo ('IO Error: {0}'.format(err))
			self._fireDownloadCancel('IO Error: {0}'.format(err))
		except (KeyboardInterrupt, SystemExit) as err:
			self._printInfo ('{0}: {1}'.format(_(u'gato_download_cancelled'), err)) #Cancelando o download:
			print err

	def _getNewFileName(self, output):
		def _getName(output, counter):
			i = output.rfind('.')
			if i > -1:
				if counter > 1:
					return output[:i-1] + str(counter) + output[i:]

				return output[:i] + str(counter) + output[i:]
			else:
				return output + str(counter)

		if not os.path.exists(output):
			return output

		nFile = _getName(output, self.counter)
		while os.path.exists(nFile):
			self.counter += 1
			nFile = _getName(output, self.counter)

		return nFile

	def convert(self, src, output):
		call(['avconv', '-i', src, '-codec', 'copy', output])

	def startDownload(self, url, output):
		self._printInfo(_(u'gato_requesting_url'))#u'Enviando requisição...')
		self.url = url
		self._fireNewFile(output)

		if 'eduk.com.br' in url:
			try:
				req = urllib2.Request(url)
				html = urllib2.urlopen(req)
			except:
				self._fireNetworkStatus(Gato.NETWORK_INTERNET_UNAVAILABLE)
				self.triedTimes = 1
				self._printError(_(u'gato_msg_no_url_found'))#u'Não foi possível encontrar a URL, verifique a conexão com a internet...')
				self.waitTime = (random.random()*10) + 3
				self._printInfo(u'{0} {1}'.format(_(u'gato_try_in_time'), StreamRecorder.format_time(self.waitTime))) #Tentado novamente em
				time.sleep(self.waitTime)
				self.startDownload(url, output)
				return

			self._printInfo(_(u'gato_interpreting_page'))#'Recebido, interpretando...')
			self._fireNetworkStatus(Gato.NETWORK_INTERNET_AVAILABLE)
			# gets the link
			try:
				src = SearchResultParser(html).parse()
			except Exception as err:
				self._printError(err)
				
			if src == '':
				self._printError(_(u'gato_cant_found_streaming_link')) #u'Não foi possível encontrar o link do streaming'
				if self.maxTryTimes >= self.triedTimes:
					self.triedTimes += 1
					self.waitTime += ((random.random()*10) * self.triedTimes)
					self._printInfo('{0} {1}'.format(_(u'gato_try_in_time'), StreamRecorder.format_time(self.waitTime))) #Tentado novamente em
					time.sleep(self.waitTime)
					self.startDownload(url, output)
			else:
				self.triedTimes = 1
				self.waitTime = 0
				self._printInfo(_(u'gato_link_found'))#'Link encontrado, iniciando o download')
				self._download('http:' + src, output)
		else:
			self._printInfo(_(u'gato_interpreting_page'))#'Recebido, interpretando...')
			self._fireNetworkStatus(Gato.NETWORK_INTERNET_AVAILABLE)
			self._download(url, output)


	def SetMessageHandler(self, msgHandler):
		self.msgHandler = msgHandler

	def SetNewFileHandler(self, newFileHandler):
		self.newFileHandler = newFileHandler

	def SetDownloadHandler(self, downloadHandler):
		self.downloadHandler = downloadHandler

	def SetProgressHandler(self, progressHandler):
		self.progressHandler = progressHandler

	def SetNetworkHandler(self, networkHandler):
		self.networkHandler = networkHandler

	def _printInfo(self, msg):
		if self.msgHandler != None:
			self.msgHandler(Gato.MSG_INFO, msg)
		else:
			print('[info] ' + msg)

	def _printError(self, msg):
		if self.msgHandler != None:
			self.msgHandler(Gato.MSG_ERROR, msg)
		else:
			print('[Error] ' + msg)

	def _fireNewFile(self, fileName):
		if self.newFileHandler != None:
			self.newFileHandler(fileName)

	def _downloadEvent(self, eventType, info):
		if self.downloadHandler != None:
			if eventType == StreamRecorder.DOWNLOAD_START:
				self.downloadHandler(Gato.DOWNLOAD_START, info)
			else:
				self.downloadHandler(Gato.DOWNLOAD_END, info)

	def _fireDownloadCancel(self, info):
		if self.downloadHandler != None:
			self.downloadHandler(Gato.DOWNLOAD_ERROR, info)

	def _fireNetworkStatus(self, eventType):
		if self.networkHandler != None:
			self.networkHandler(eventType)

	'''def _fireDownloadStart(self):
		if self.downloadHandler != None:
			self.downloadHandler(streamrecorder.DOWNLOAD_START)

	def _fireDownloadEnd(self):
		if self.downloadHandler != None:
			self.downloadHandler(streamrecorder.DOWNLOAD_END)

	def _fireProgressUpdate(self, msg):
		if self.progressHandler != None:
			self.progressHandler(msg)'''

def usage():
	return _(u'gato_usage')
	"""return 
	Faz download os videos da eduk.com.br

	Para gravar o video:
	    python gato -u <url> -o <arquivo saída>

	Depois de gravar:
	    python gato -i <video> -o <arquivo saída>
	"""

#main()
