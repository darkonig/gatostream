#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Created on 16/12/2014

@author: dk
'''
import argparse
from gato.ui.mainwindow import MainWindow
import wx

def main():
    parser = argparse.ArgumentParser(description='Gato Stream download vídeos dailymotion.com/live, livestream.com, twitch.tv, ustream.tv, youtube.com, eduk.com.br')

    group = parser.add_argument_group('Para baixar o arquivo')
    group.add_argument('-u', '--url', type=str, help='URL da pagina do stream')
    group.add_argument('-o', '--output', type=str, help='Arquivo de saída')
    
    args = parser.parse_args()
    
    app = wx.App()
    MainWindow(None, args)
    app.MainLoop()
    
if __name__ == '__main__':    
    main()