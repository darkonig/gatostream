# -*- coding: utf-8 -*-
'''
Created on 29/12/2014

@author: dk
'''
import os
from ConfigParser import SafeConfigParser
import sys

SYSTEM_NAME = 'GatoStream'
SYSTEM_VERSION = '0.4'
SYSTEM_UPDATE_VERIFY_URL = 'https://raw.githubusercontent.com/darkonig/gatostream/master/release/'
SYSTEM_UPDATE_URL = 'http://gato.feijaodecorda.com/'

DEFAULT_LANG = 'en'
_CURRENT_LANG = None
_conf = None
LANGUAGES = {
    'en': 'English',
    'pt_BR': u'Português Brasileiro'
}

OS_WINDOWS = 'WIN'
OS_LINUX = 'LINUX'
OS_MAC = 'MAC'
OS_UNKNOWN = 'UNKNOWN'

_OS_TYPE = None

def _getOS():
    global _OS_TYPE
    if sys.platform.startswith('win'):
        _OS_TYPE = OS_WINDOWS
    elif sys.platform.startswith('linux'):
        _OS_TYPE = OS_LINUX
    elif sys.platform.startswith('darwin'):
        _OS_TYPE = OS_MAC
    else:
        _OS_TYPE = OS_UNKNOWN

def getOS():
    if not _OS_TYPE:
        _getOS()
        
    return _OS_TYPE

def _getConfigPath():
    import appdirs
    appname = "GatoStream"
    appauthor = "DK"
    dataDir = appdirs.user_data_dir(appname, appauthor)
    dataFile = dataDir + '/config.cfg'
    
    return dataFile

def getLang():
    global _CURRENT_LANG, _conf
    
    if _CURRENT_LANG:
        return _CURRENT_LANG
        
    _getConfig()
    if _conf:
        _CURRENT_LANG = _conf.get('main', 'lang')
        return _CURRENT_LANG
    else:
        _CURRENT_LANG = DEFAULT_LANG
    
    return DEFAULT_LANG

def setLang(lang):
    global _CURRENT_LANG
    
    _CURRENT_LANG = lang

def getPlayerPath():
    global _conf
    
    if not _conf:
        _getConfig()
        if _conf == None:
            return None
        
    try:
        return _conf.get('main', 'player_path')
    except:
        return None

def _getConfig():
    global _conf
    dataFile = _getConfigPath()
    
    _conf = None
    
    if not os.path.exists(dataFile):
        return None;
    
    try:
        _conf = SafeConfigParser()
        _conf.read(dataFile)
        #return config.get('main', 'player_path')
        return _conf
    except:
        
        return None

def saveConfig(playerPath, lang):
    global _conf
        
    dataFile = _getConfigPath()
    
    if not os.path.exists(os.path.dirname(dataFile)):
        os.makedirs(os.path.dirname(dataFile))

    config = SafeConfigParser()
    config.read(dataFile)
    if not config.has_section('main'):
        config.add_section('main')
    
    if playerPath:
        config.set('main', 'player_path', playerPath)
        
    if lang:
        config.set('main', 'lang', lang)

    with open(dataFile, 'w') as f:
        config.write(f)