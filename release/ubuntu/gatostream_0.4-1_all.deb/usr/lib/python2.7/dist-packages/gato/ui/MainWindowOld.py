#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Created on 10/12/2014

@author: dk
'''
import wx
from gato.core.gato import Gato
import sys
import threading
import argparse
import subprocess
import os
import time
from subprocess import Popen
from threading import Thread

# Define notification event for thread completion
EVT_OPEN_PLAYER_ID = wx.NewId()

def EVT_OPEN_PLAYER(win, func):
    """Define Result Event."""
    win.Connect(-1, -1, EVT_OPEN_PLAYER_ID, func)
 
class OpenPlayerEvent(wx.PyEvent):
    """Simple event to carry arbitrary result data."""
    def __init__(self, cmd):
        """Init Result Event."""
        wx.PyEvent.__init__(self)
        self.SetEventType(EVT_OPEN_PLAYER_ID)
        self.cmd = cmd

class OpenPlayerThread(Thread):
    """Test Worker Thread Class."""
 
    #----------------------------------------------------------------------
    def __init__(self, wxObject, playerPath, filePath):
        """Init Worker Thread Class."""
        Thread.__init__(self)
        self.wxObject = wxObject
        self.playerPath = playerPath
        self.filePath = filePath
        self.start()    # start the thread
 
    #----------------------------------------------------------------------
    def run(self):
        time.sleep(1)
        fileinfo = os.stat(self.filePath)
        if fileinfo.st_size < 1024:
            self._openPlayer()
            return
            
        osCommandExecute = ''
        if sys.platform.startswith('win'):
            #osCommandExecute = ['start', self.playerPath, args.output]
            osCommandExecute = 'start "{0}" "{1}"'.format(self.playerPath, self.filePath)
        elif sys.platform.startswith('linux'):
            #osCommandExecute = ['open', self.playerPath, args.output]
            osCommandExecute = 'open "{0}" "{1}"'.format(self.playerPath, self.filePath)
        else:
            #osCommandExecute = ['open', self.playerPath, '--args', args.output]
            osCommandExecute = 'open "{0}" --args "{1}"'.format(self.playerPath, self.filePath)
                
        wx.PostEvent(self.wxObject, OpenPlayerEvent(osCommandExecute))
        

class MainWindow(wx.Frame):
    def __init__(self, parent, args):
        super(MainWindow, self).__init__(parent, title='Eduk Recorder', size=(495, 305), 
                                         style=wx.MINIMIZE_BOX | wx.CAPTION | wx.CLOSE_BOX)
        
        self.currentFile = None
        self.playerPath = None
        
        self.InitUI(args)
        self.Centre()
        self.Show()
    
    def InitUI(self, args):
        panel = wx.Panel(self, -1)
        
        icon = wx.Icon('../../img/icon.png', wx.BITMAP_TYPE_ANY)
        self.SetIcon(icon)
        
        textHeight = 22
        startPosY = 10
        startPosX = 12
        
        wx.StaticText(panel, label='URL', pos=(startPosX, startPosY))
        self.textURL = wx.TextCtrl(panel, pos=(startPosX + 57, startPosY), size=(400, textHeight))
        if args.url != None:
            self.textURL.SetValue(args.url)
        
        wx.StaticText(panel, label=u'Saída', pos=(startPosX, startPosY + 35), size=(80, textHeight))
        self.textOutput = wx.TextCtrl(panel, pos=(startPosX + 57, startPosY + 35), size=(365, textHeight))
        
        if args.output != None:
            self.textOutput.SetValue(args.output)
        
        btnSelectFile = wx.Button(panel, pos=(startPosX + 420, startPosY + 30), label='...', size=(30, textHeight))
        btnSelectFile.Bind(wx.EVT_BUTTON, self.OnSelectFile)
        
        self.chkPlayVideo = wx.CheckBox(panel, pos=(startPosX, startPosY + 65), label='Iniciar player')
        
        self.lstVideos = wx.ListCtrl(panel, pos=(startPosX, startPosY + 90), size=(460, 140), style=wx.LC_REPORT | wx.SUNKEN_BORDER)
        self.lstVideos.InsertColumn(0, 'Nome', width=200)
        self.lstVideos.InsertColumn(1, 'Status', width=100)
        self.lstVideos.InsertColumn(2, 'Info', width=150)
        self.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.ListVideoClick, self.lstVideos)
        
        self.btnFix = wx.Button(panel, pos=(380, startPosY + 235), size=(80, textHeight), label='Gravar')
        self.btnFix.Bind(wx.EVT_BUTTON, self.StartRecord)
        
        self.statusLabel = wx.StaticText(panel, label=u'Não iniciada a gravação', 
                                         pos=(startPosX, startPosY + 235), size=(335, textHeight))
       
        bmp = wx.Image('../../img/con_none.png', wx.BITMAP_TYPE_ANY)
        self.connectionLabel = wx.StaticBitmap(panel, bitmap=wx.BitmapFromImage(bmp),
                                         pos=(startPosX + 340, startPosY + 240), size=(18, 18))
        self.connectionLabel.SetToolTip(wx.ToolTip('[Internet Status] Desconhecido'))
        
        # Create some controls
        '''try:
			self.mc = wx.media.MediaCtrl(panel, pos=(startPosX + 380, startPosY), style=wx.SIMPLE_BORDER)
		except NotImplementedError:
			self.Destroy()
			raise
		
		if not self.mc.Load(args.output):
			wx.MessageBox(u"Não foi possível reproduzir '%s': Formatdo não suportado" % args.output, "ERROR", wx.ICON_ERROR | wx.OK)
		else:			
			self.mc.SetBestFittingSize()
			self.GetSizer().Layout()
			self.slider.SetRange(0, self.mc.Length())
			self.mc.Play()'''
        
        EVT_OPEN_PLAYER(self, self._openPlayerInThread)
        
        # Get Player Path
        self.playerPath = self._getPlayerConfig()
        if self.playerPath == None:
            osCommandExecute = ''
            if sys.platform.startswith('win'):
                osCommandExecute = ['Executable file', 'Executable File (*.exe)|*.exe']
            elif sys.platform.startswith('linux'):
                osCommandExecute = ['Executable file', 'Executable File (*.*)|*.*']
            else:
                osCommandExecute = ['Application', 'Application (*.app)|*.app']
            
            dial = wx.MessageDialog(None, u'Para que possa fazer download e reproduzir o vídeo primeiro selecione o um Player de Vídeo (que reproduza .MP4)', 
                                    u'Selecione um player de vídeo', wx.OK | wx.ICON_INFORMATION)
            dial.ShowModal()
            
            openFileDialog = wx.FileDialog(self, osCommandExecute[0], "", "", osCommandExecute[1], wx.FD_OPEN)
            if openFileDialog.ShowModal() == wx.ID_CANCEL:
                self.chkPlayVideo.Enable(False)
                return
            
            self.playerPath = openFileDialog.GetPath()
            self._savePlayerConfig(self.playerPath)
        
    def OnSelectFile(self, event):
        saveFileDialog = wx.FileDialog(self, "Save MP4 file", "", "",
                                   "MP4 files (*.mp4)|*.mp4", wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT)
        
        if saveFileDialog.ShowModal() == wx.ID_CANCEL:
            return
        
        self.textOutput.SetValue(saveFileDialog.GetPath())
    
    def StartRecord(self, event):        
        if self.textURL.GetValue() == '' and self.textOutput.GetValue() == '':
            dial = wx.MessageDialog(None, u'Preencha a URL e Saída.', 'Error', wx.OK | wx.ICON_ERROR)
            dial.ShowModal()
            return
        
        self.btnFix.Enable(False)
        self.textOutput.Enable(False)
        self.textURL.Enable(False)
        
        try:
            t = threading.Thread(target=self._start, args = ())
            t.daemon = True
            t.start()
        except:
            print "Error: unable to start thread"
        
    def _start(self):
        gato = Gato()
        gato.SetMessageHandler(self.MsgHandler)
        gato.SetDownloadHandler(self.DownloadEvent)
        gato.SetNewFileHandler(self.NewFileEvent)
        gato.SetProgressHandler(self.DownloadProgressEvent)
        gato.SetNetworkHandler(self.NetworkEvent)
        
        gato.startDownload(self.textURL.GetValue(), self.textOutput.GetValue())
        
        
    def MsgHandler(self, eventType, msg):
        self.statusLabel.SetLabelText(msg)
    
    def DownloadEvent(self, eventType, info):
        if eventType == Gato.DOWNLOAD_END:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Finalizado')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
        elif eventType == Gato.DOWNLOAD_ERROR:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Error')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
        else:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Baixando')
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, info)
            
            if self.chkPlayVideo.IsChecked() and self.playerPath != None:
                '''try:
                    t = threading.Thread(target=self._openPlayer, args = ())
                    t.daemon = True
                    t.start()
                except:
                    print "Error: unable to start thread"'''
                print ('Abrindo: ' + self.lstVideos.GetItem(self.lstVideos.GetItemCount()-1, 0).GetText())
                OpenPlayerThread(self, self.playerPath, self.lstVideos.GetItem(self.lstVideos.GetItemCount()-1, 0).GetText())
    
    """def _openPlayer(self):
        time.sleep(1)
        fileinfo = os.stat(self.textOutput.GetValue())
        if fileinfo.st_size < 1024:
            self._openPlayer()
            return
            
        osCommandExecute = ''
        if sys.platform.startswith('win'):
            osCommandExecute = ['start', self.playerPath, args.output]
        elif sys.platform.startswith('linux'):
            osCommandExecute = ['open', self.playerPath, args.output]
        else:
            osCommandExecute = ['open', self.playerPath, '--args', args.output]
        
        x = ''
        for w in osCommandExecute:
            x += w + ' '
        
        wx.Process().Open(x)
        #subprocess.call(osCommandExecute)
        '''p = Popen(osCommandExecute, stdout= subprocess.PIPE)
        try:
            out, err = p.communicate()
        except (KeyboardInterrupt, SystemExit):
            self._printInfo ('Cancelando o donwload')
            return
        
        rc = p.returncode'''"""
        
    def _openPlayerInThread(self, event):
        wx.Process().Open(event.cmd)
    
    def ListVideoClick(self, event):
        print ('Abrindo: ' + event.GetText())
        if self.playerPath != None:
            OpenPlayerThread(self, self.playerPath, event.GetText())
        
    def _savePlayerConfig(self, playerPath):
        import appdirs
        from ConfigParser import SafeConfigParser
        appname = "Eduk Downloader"
        appauthor = "DK"
        dataDir = appdirs.user_data_dir(appname, appauthor)
        dataFile = dataDir + '/config.cfg'
        
        if not os.path.exists(dataDir):
            os.makedirs(dataDir)
        
        config = SafeConfigParser()
        config.read(dataFile)
        config.add_section('main')
        config.set('main', 'player_path', playerPath)
        
        with open(dataFile, 'w') as f:
            config.write(f)
            
    def _getPlayerConfig(self):
        import appdirs
        from ConfigParser import SafeConfigParser
        appname = "Eduk Downloader"
        appauthor = "DK"
        dataDir = appdirs.user_data_dir(appname, appauthor)
        dataFile = dataDir + '/config.cfg'
        
        try:
            config = SafeConfigParser()
            config.read(dataFile)
            return config.get('main', 'player_path')
        except:
            return None        
        
    def NewFileEvent(self, filename):
        if self.currentFile == filename:
            return
        
        self.currentFile = filename
        index = self.lstVideos.InsertStringItem(sys.maxint, filename)
        self.lstVideos.SetStringItem(index, 1, 'Conectando')
    
    def DownloadProgressEvent(self, msg):
        #wx.CallAfter(
        self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 2, msg)
        pass
    
    def NetworkEvent(self, networkStatus):
        #wx.CallAfter(
        if networkStatus == Gato.NETWORK_INTERNET_AVAILABLE:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, 'Iniciando')
            bmp = wx.Image('../../img/con_available.png', wx.BITMAP_TYPE_ANY)
            self.connectionLabel.SetBitmap(wx.BitmapFromImage(bmp))
            self.connectionLabel.SetToolTip(wx.ToolTip('[Internet Status] Conectado'))
        else:
            self.lstVideos.SetStringItem(self.lstVideos.GetItemCount()-1, 1, u'Sem conexão')
            bmp = wx.Image('../../img/con_unavailable.png', wx.BITMAP_TYPE_ANY)
            self.connectionLabel.SetBitmap(wx.BitmapFromImage(bmp))
            self.connectionLabel.SetToolTip(wx.ToolTip(u'[Internet Status] Sem conexão'))
        pass
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Faz download os videos da eduk.com.br')

    group = parser.add_argument_group('Para baixar o arquivo')
    group.add_argument('-u', '--url', type=str, help='URL da pagina da eduk')
    group.add_argument('-o', '--output', type=str, help='Arquivo de saída')
    
    args = parser.parse_args()
    
    app = wx.App()
    MainWindow(None, args)
    app.MainLoop()