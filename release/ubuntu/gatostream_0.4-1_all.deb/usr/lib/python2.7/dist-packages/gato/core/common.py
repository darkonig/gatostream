# -*- coding: utf-8 -*-
'''
Created on 26/12/2014

@author: dk
'''

import os
#import pkg_resources
#from ..ui import baseui
from .. import base
   
#def get_version():
#    """
#    Returns the program version from the egg metadata
#    :returns: the version of Gato
#    :rtype: string
#    """
#    return pkg_resources.require("GatoStream")[0].version

def get_pixmap(fname):
    """
    Provides easy access to files in the gato/ui/data/pixmaps folder within the Gato egg
    :param fname: the filename to look for
    :type fname: string
    :returns: a path to a pixmap file included with Gato
    :rtype: string
    """
    '''# doesnt works in mac after py2app
    #return resource_filename("gato", os.path.join("ui", "data", "pixmaps", fname))
    if os.path.exists(os.path.dirname(baseui.__file__)):
        return os.path.join(os.path.abspath(os.path.dirname(baseui.__file__)), "data", "pixmaps", fname)
    
    # returning if the app is on a package (library.zip)
    return os.path.join("ui","data","pixmaps", fname)'''
    return os.path.join(resource_filename(), "ui","data","pixmaps", fname)
    

def get_translations_path():
    """Get the absolute path to the directory containing translation files"""
    #stdlib_dir = os.path.abspath(os.path.dirname(base.__file__))
    return os.path.join(resource_filename(), 'i18n')

def resource_filename():
    return os.path.abspath(os.path.dirname(base.__file__))

"""def resource_filename(module, path):
    # While developing, if there's a second gatoStream package, installed globally
    # and another in develop mode somewhere else, while pkg_resources.require("GatoStream")
    # returns the proper gatoStream instance, pkg_resources.resource_filename does
    # not, it returns the first found on the python path, which is not good
    # enough.
    # This is a work-around that.
    return pkg_resources.require("GatoStream>=%s" % get_version())[0].get_resource_filename(
        pkg_resources._manager, os.path.join(*(module.split(".") + [path]))
    )"""
