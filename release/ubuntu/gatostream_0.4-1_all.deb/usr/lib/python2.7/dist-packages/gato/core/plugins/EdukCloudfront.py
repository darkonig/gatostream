'''
Created on 15/12/2014

@author: dk
'''
import re

from livestreamer.plugin import Plugin
from livestreamer.plugin.api import http, validate
'''from livestreamer.compat import urljoin
from livestreamer.plugin.api.utils import parse_json
from livestreamer.stream import AkamaiHDStream, HLSStream'''
from livestreamer.stream import HLSStream

_url_re = re.compile("http(s)?://player.eduk.com.br/")
'''_stream_config_schema = validate.Schema({
    "event": {
        "stream_info": validate.any({
            "is_live": bool,
            "qualities": [{
                "bitrate": int,
                "height": int
            }],
            validate.optional("play_url"): validate.url(scheme="http"),
            validate.optional("m3u8_url"): validate.url(
                scheme="http",
                path=validate.endswith(".m3u8")
            ),
        }, None)
    },
    validate.optional("viewerPlusSwfUrl"): validate.url(scheme="http"),
    validate.optional("hdPlayerSwfUrl"): validate.text
})
_smil_schema = validate.Schema(validate.union({
    "http_base": validate.all(
        validate.xml_find("{http://www.w3.org/2001/SMIL20/Language}head/"
                          "{http://www.w3.org/2001/SMIL20/Language}meta"
                          "[@name='httpBase']"),
        validate.xml_element(attrib={
            "content": validate.text
        }),
        validate.get("content")
    ),
    "videos": validate.all(
        validate.xml_findall("{http://www.w3.org/2001/SMIL20/Language}body/"
                             "{http://www.w3.org/2001/SMIL20/Language}switch/"
                             "{http://www.w3.org/2001/SMIL20/Language}video"),
        [
            validate.all(
                validate.xml_element(attrib={
                    "src": validate.text,
                    "system-bitrate": validate.all(
                        validate.text,
                        validate.transform(int)
                    )
                }),
                validate.transform(
                    lambda e: (e.attrib["src"], e.attrib["system-bitrate"])
                )
            )
        ],
    )
}))'''


class Edukstream(Plugin):
    @classmethod
    def default_stream_types(cls, streams):
        return ["akamaihd", "hls"]

    @classmethod
    def can_handle_url(self, url):
        return _url_re.match(url)

    def _get_stream_info(self):
        res = http.get(self.url)
        # http://d2y0jtcvp09078.cloudfront.net/live_02/smil:live_2002.smil/media_b1864000_1863.ts
        #live_02/smil:live_2002.smil
        match = re.search('data-cdn="(.+)"', res.text)
        
        if match:
            # get id from eduk
            idl = self.url.rfind('/')
            ids = self.url[:idl].rfind('/')+1
            ideduk = self.url[ids:idl]
            
            cdn = match.group(1)
            return 'https://'+ cdn + '/live_02/smil:live_' + ideduk + '.smil/playlist.m3u8'

    '''def _parse_smil(self, url, swf_url):
        res = http.get(url)
        smil = http.xml(res, "SMIL config", schema=_smil_schema)

        for src, bitrate in smil["videos"]:
            url = urljoin(smil["http_base"], src)
            yield bitrate, AkamaiHDStream(self.session, url, swf=swf_url)'''

    def _get_streams(self):
        #info = self._get_stream_info()
        #if not info:
        #    return
        #swf_url = 'http://player.eduk.com.br/jwplayer.flash.swf'

        m3u8_url = self._get_stream_info()
        
        if m3u8_url:
            streams = HLSStream.parse_variant_playlist(self.session, m3u8_url, namekey="pixels")
            # TODO: Replace with "yield from" when dropping Python 2.
            for stream in streams.items():
                yield stream

__plugin__ = Edukstream
