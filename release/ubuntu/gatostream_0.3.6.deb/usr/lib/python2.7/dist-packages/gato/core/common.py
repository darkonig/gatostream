# -*- coding: utf-8 -*-
'''
Created on 26/12/2014

@author: dk
'''

import os
import pkg_resources

def get_version():
    """
    Returns the program version from the egg metadata
    :returns: the version of Gato
    :rtype: string
    """
    return pkg_resources.require("GatoStream")[0].version

def get_pixmap(fname):
    """
    Provides easy access to files in the gato/ui/data/pixmaps folder within the Gato egg
    :param fname: the filename to look for
    :type fname: string
    :returns: a path to a pixmap file included with Gato
    :rtype: string
    """
    return resource_filename("gato", os.path.join("ui", "data", "pixmaps", fname))


def resource_filename(module, path):
    # While developing, if there's a second gatoStream package, installed globally
    # and another in develop mode somewhere else, while pkg_resources.require("GatoStream")
    # returns the proper gatoStream instance, pkg_resources.resource_filename does
    # not, it returns the first found on the python path, which is not good
    # enough.
    # This is a work-around that.
    return pkg_resources.require("GatoStream>=%s" % get_version())[0].get_resource_filename(
        pkg_resources._manager, os.path.join(*(module.split(".") + [path]))
    )
