#!/usr/bin/python
# encoding: utf-8
'''
Created on 11/12/2014

@author: jana
'''
import sys

from livestreamer import Livestreamer, StreamError, PluginError, NoPluginError
from livestreamer_cli.output import FileOutput, PlayerOutput
from contextlib import closing

from livestreamer_cli import main

import time
from collections import deque
import os
import plugins

import m3u8
from livestreamer.stream.http import HTTPStream


class StreamRecorder:
    MSG_INFO = 0
    MSG_ERROR = 1
    
    DOWNLOAD_START = 1
    DOWNLOAD_END = 2
    
    def __init__(self, url, outputfile, quality='best'):
        self.url = url
        self.quality = quality
        self.outputfile = outputfile
        self.msgHandler = None
        self.progressHandler = None
        self.downloadHandler = None
    
    def saveStream(self):
        session = Livestreamer()
        # Enable logging
        session.set_loglevel("info")
        session.set_logoutput(sys.stdout)
        session.set_option('http-timeout', 2.0)
        
        session.set_option('http-stream-timeout', 2.0)
        session.set_option('stream-timeout', 2.0)
        session.set_option('stream-segment-timeout', 2.0)
        
        session.set_option("rtmp-timeout", 2.0)
        
        session.set_option("hds-timeout", 2.0)
        session.set_option("hds-segment-timeout", 2.0)
        
        session.set_option("hls-timeout", 2.0)
        session.set_option("hls-segment-timeout", 2.0)
        
        #load plugins
        if os.path.isdir(main.PLUGINS_DIR):
            session.load_plugins(main.PLUGINS_DIR)
        
        session.load_plugins(os.path.dirname(plugins.__file__))
        
        # Attempt to fetch streams
        try:
            print('Processing streaming from: {0}'.format(self.url))
            streams = session.streams(self.url)
        except NoPluginError:
            self._printError("[PLUGIN ERROR] Não é possível utilizar a URL '{0}'".format(self.url))
            raise StreamError("Livestreamer is unable to handle the URL '{0}'".format(self.url))
        except PluginError as err:
            self._printError("Plugin error: '{0}'".format(err))
            raise StreamError("Plugin error: {0}".format(err))
        except Exception as e:
            raise e
        
        print ('---- Streams found: {0}'.format(streams))
        if not streams:
            self._printError("Stream não encontrada na url '{0}'".format(self.url))
            raise StreamError("No streams found on URL '{0}'".format(self.url))
            
        # Look for specified stream
        if self.quality not in streams:
            self._printError("Não foi possível encontrar '{0}' na url '{1}'".format(self.quality, self.url))
            raise StreamError("Unable to find '{0}' stream on URL '{1}'".format(self.quality, self.url))
            
        # We found the stream
        stream = streams[self.quality]
        
        print('tryng to process streaming from: {0}'.format(stream.url))
        # if is list
        if stream.url.endswith('.m3u8'):
            self._download_stream_multipart(session, stream)
            return
        
        self._download_stream(stream)
        
        return True
    
    def _download_stream_multipart(self, session, stream):
        self._print_info('Multiparted streaming')
        
        listPartsDownloaded = []
        out = None
        while stream is not None:
            try:
                res = session.http.get(stream.url)
                base_uri = stream.url[:stream.url.rfind('/')+1]
                parser = m3u8.loads(res.text)
                
                for playlist in parser.segments:
                    if playlist.uri in listPartsDownloaded:
                        continue
                    
                    listPartsDownloaded.append(playlist.uri)
                    print (playlist.uri)
                    out = self._download_stream(HTTPStream(session, base_uri + playlist.uri),
                                          out, True)
                    time.sleep(playlist.duration/2)
            except:
                raise
            
            # clear some list of downloaded parts
            if len(listPartsDownloaded) > 50:
                for i in range(0, len(listPartsDownloaded) - 50):
                    listPartsDownloaded.remove(0)
            
            try:
                streams = session.streams(self.url)
            except NoPluginError:
                self._printError("Não é possível utilizar a URL '{0}'".format(self.url))
                raise StreamError("Livestreamer is unable to handle the URL '{0}'".format(self.url))
            except PluginError as err:
                self._printError("Plugin error: '{0}'".format(err))
                raise StreamError("Plugin error: {0}".format(err))
            
            stream = streams[self.quality]
        
        if out is not None:
            out.close()
            self._fireDownloadEnd( StreamRecorder.format_filesize(
                                                self.format_filesize(os.stat(out.filename).st_size)) )
        print('Streaming ended')
    
    
    
    def _download_stream(self, stream, output = None, keepOpen = False):
        print("Reading Stream '{0}'".format(stream.url))
        # Attempt to open the stream
        try:
            stream_fd = stream.open()
        except StreamError as err:
            self._printError(u"Falha ao abrir a saída: {0}".format(err))
            raise StreamError("Failed to open stream: {0}".format(err))
        except:
            raise

        print("Stream aberta")
        # Read 8192 bytes before proceeding to check for errors.
        # This is to avoid opening the output unnecessarily.
        try:
            prebuffer = stream_fd.read(8192)
        except IOError as err:
            #raise StreamError("Failed to read data from stream: {0}".format(err))
            raise StreamError("Falha ao ler strem: {0}".format(err))

        if not prebuffer:
            #raise StreamError("No data returned from stream")
            raise StreamError("Stream sem dados")

        # create output
        # output = FileOutput(filename=outfile, fd=stream_fd)
        if output is None:
            output = FileOutput(filename=self.outputfile)
            
            try:
                output.open()
            except (IOError, OSError) as err:
                self._printError("Falha ao abrir a saída: {0} ({1})".format(self.outputfile, err))
                raise IOError("Failed to open output: {0} ({1})".format(self.outputfile, err))

        #with closing(output):
        self._printInfo("Writing stream to output")
        self._read_stream(stream_fd, output, prebuffer, keepOpen)
        if not keepOpen:
            output.close()
            
        return output
    
    
    def _read_stream(self, stream, output, prebuffer, keepOpen=False, chunk_size=8192):
        """Reads data from stream and then writes it to the output."""
        is_player = isinstance(output, PlayerOutput)
        is_http = isinstance(output, main.HTTPServer)
        is_fifo = is_player and output.namedpipe
        
        stream_iterator = main.chain(
            [prebuffer],
            iter(main.partial(stream.read, chunk_size), b"")
        )
        self._fireDownloadStart('Downloading')
        
        stream_iterator = self.progress(stream_iterator, prefix="--")
        
        written = 0
        try:
            for data in stream_iterator:
                written += len(data)
                
                # We need to check if the player process still exists when
                # using named pipes on Windows since the named pipe is not
                # automatically closed by the player.
                if main.is_win32 and is_fifo:
                    output.player.poll()
                    
                    if output.player.returncode is not None:
                        print("Player closed")
                        break
                       
                try:
                    output.write(data)
                except IOError as err:
                    if is_player and err.errno in main.ACCEPTABLE_ERRNO:
                        print("Player closed")
                    elif is_http and err.errno in main.ACCEPTABLE_ERRNO:
                        print("HTTP connection closed")
                    else:
                        self._printError("Error when writing to output: {0}", err)
                        
                    break
        except IOError as err:
            self._printError("Error when reading from stream: {0}", err)
            
        stream.close()
        self._printInfo("Stream ended")
        if not keepOpen:
            self._fireDownloadEnd(self.format_filesize(written))
        else:
            self._fireProgressUpdate('Aguardando...')
    
    
    def progress(self, iterator, prefix):
        """Progress an iterator and updates a pretty status line to the terminal.
    
        The status line contains:
         - Amount of data read from the iterator
         - Time elapsed
         - Average speed, based on the last few seconds.
        """
        prefix = (".." + prefix[-23:]) if len(prefix) > 25 else prefix
        speed_updated = start = time.time()
        speed_written = written = 0
        speed_history = deque(maxlen=5)
        
        for data in iterator:
            yield data
            
            now = time.time()
            elapsed = now - start
            written += len(data)
            
            speed_elapsed = now - speed_updated
            if speed_elapsed >= 0.5:
                speed_history.appendleft((
                    written - speed_written,
                    speed_updated,
                ))
                speed_updated = now
                speed_written = written
                
                speed_history_written = sum(h[0] for h in speed_history)
                speed_history_elapsed = now - speed_history[-1][1]
                speed = speed_history_written / speed_history_elapsed
                
                status = '{written} ({elapsed} @ {speed}/s)'.format(prefix=prefix,
                    written=StreamRecorder.format_filesize(written),
                    elapsed=StreamRecorder.format_time(elapsed),
                    speed=StreamRecorder.format_filesize(speed)
                )
                self._fireProgressUpdate(status)
        
    @staticmethod
    def format_time(elapsed):
        """Formats elapsed seconds into a human readable format."""
        hours = int(elapsed / (60 * 60))
        minutes = int((elapsed % (60 * 60)) / 60)
        seconds = int(elapsed % 60)
        
        rval = ""
        if hours:
            rval += "{0}h".format(hours)
            
        if elapsed > 60:
            rval += "{0}m".format(minutes)
            
        rval += "{0}s".format(seconds)
        return rval
    
    @staticmethod
    def format_filesize(size):
        """Formats the file size into a human readable format."""
        for suffix in ("bytes", "KB", "MB", "GB", "TB"):
            if size < 1024.0:
                if suffix in ("GB", "TB"):
                    return "{0:3.2f} {1}".format(size, suffix)
                else:
                    return "{0:3.1f} {1}".format(size, suffix)
    
            size /= 1024.0
    
    def SetMessageHandler(self, msgHandler):
        self.msgHandler = msgHandler
        
    def SetDownloadHandler(self, downloadHandler):
        self.downloadHandler = downloadHandler
        
    def SetProgressHandler(self, progressHandler):
        self.progressHandler = progressHandler
    
    def _printInfo(self, msg):
        if self.msgHandler != None:
            self.msgHandler(StreamRecorder.MSG_INFO, msg)
        else:
            print('[info] ' + msg)
        
    def _printError(self, msg):
        if self.msgHandler != None:
            self.msgHandler(StreamRecorder.MSG_ERROR, msg)
        
        print('[Error] ' + msg)
    
    def _fireDownloadStart(self, info):
        if self.downloadHandler != None:
            self.downloadHandler(StreamRecorder.DOWNLOAD_START, info)
            
    def _fireDownloadEnd(self, info):
        if self.downloadHandler != None:
            self.downloadHandler(StreamRecorder.DOWNLOAD_END, info)
            
    def _fireProgressUpdate(self, msg):
        if self.progressHandler != None:
            self.progressHandler(msg)
        else:
            print('[Downloading] ' + msg)