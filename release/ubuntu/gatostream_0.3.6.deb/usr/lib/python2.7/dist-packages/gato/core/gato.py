#!/usr/bin/python
# encoding: utf-8
from livestreamer.exceptions import *

import urllib2

from livestreamer import Livestreamer
from subprocess import call, PIPE, Popen
import sys, getopt
import lxml.html

#import signal
import time, random

import argparse
from streamrecorder import StreamRecorder
import os

class SearchResultParser:
	def __init__(self, html):
		self.doc = lxml.html.parse(html).getroot()

	def parse(self):
		src = ''
		try:
			video = self.doc.xpath('//*[@id="live-video"]')[0]
			iframe = [item for item in video.iterchildren() if item.tag == 'iframe']
			src = iframe[0].attrib['src']
		except:
			print ('############## Erro na interpretação ##################')
			pass
		return src

class Gato:
	MSG_INFO = 0
	MSG_ERROR = 1

	DOWNLOAD_START = 1
	DOWNLOAD_END = 2
	DOWNLOAD_ERROR = 3

	NETWORK_INTERNET_UNAVAILABLE = 1
	NETWORK_INTERNET_AVAILABLE = 2

	def __init__(self):
		self.counter = 0
		self.triedTimes = 1
		self.maxTryTimes = 5
		self.waitTime = 0
		self.url = ''
		self._signal_handle()

		self.msgHandler = None
		self.downloadHandler = None
		self.progressHandler = None
		self.newFileHandler = None
		self.networkHandler = None
		pass

	def play(self, src):
		from livestreamerplayer import LivestreamerPlayer
		quality = 'best'
		livestreamer = Livestreamer()

		# Enable logging
		livestreamer.set_loglevel("info")
		livestreamer.set_logoutput(sys.stdout)

		# Attempt to find a plugin for this URL
		try:
			plugin = livestreamer.resolve_url(src)
		except NoPluginError:
			exit("Livestreamer is unable to handle the URL '{0}'".format(src))

		# Attempt to fetch streams
		try:
			streams = plugin.get_streams()
		except PluginError as err:
			exit("Plugin error: {0}".format(err))

		if len(streams) == 0:
			exit("No streams found on URL '{0}'".format(src))

		# Look for specified stream
		if quality not in streams:
			exit("Unable to find '{0}' stream on URL '{1}'".format(quality, src))

		# We found the stream
		stream = streams[quality]

		# Create the player and start playback
		player = LivestreamerPlayer()

		#out = FileOutput(fd=stdout)
		# Blocks until playback is done
		player.play(stream)

	def _signal_handle(self):
		#ignore CTRL+C (Interrupt)
		#signal.signal(signal.SIGINT, signal.SIG_IGN)
		print ('signal')

	def _download(self, src, output):
		'''#_download(['livestreamer', src, 'best', '-o', output])
		p = Popen(['livestreamer', src, 'best', '-o', output])
		try:
			out, err = p.communicate()
		except (KeyboardInterrupt, SystemExit):
			self._printInfo ('Cancelando o donwload')
			return

		rc = p.returncode
		self._printInfo('Download finalizado ({0})'.format(rc));
		if rc == 0:
			self.startDownload(self.url, output + str(self.counter))'''
		stream = StreamRecorder(src, output)
		stream.SetMessageHandler(self.msgHandler)
		stream.SetDownloadHandler(self._downloadEvent)
		stream.SetProgressHandler(self.progressHandler)
		try:
			if stream.saveStream():
				self._printInfo('Download finalizado.');

			self.startDownload(self.url, self._getNewFileName(output))
		except StreamError as err:
			self._printInfo ('Error: {0}'.format(err))
			self._fireDownloadCancel('Error: {0}'.format(err))

			self.startDownload(self.url, self._getNewFileName(output))
		except IOError as err:
			self._printInfo ('IO Error: {0}'.format(err))
			self._fireDownloadCancel('IO Error: {0}'.format(err))
		except (KeyboardInterrupt, SystemExit) as err:
			self._printInfo ('Cancelando o download: {0}'.format(err))
			print err

	def _getNewFileName(self, output):
		def _getName(output, counter):
			i = output.rfind('.')
			if i > -1:
				if counter > 1:
					return output[:i-1] + str(counter) + output[i:]

				return output[:i] + str(counter) + output[i:]
			else:
				return output + str(counter)

		if not os.path.exists(output):
			return output

		nFile = _getName(output, self.counter)
		while os.path.exists(nFile):
			self.counter += 1
			nFile = _getName(output, self.counter)

		return nFile

	def convert(self, src, output):
		call(['avconv', '-i', src, '-codec', 'copy', output])

	def startDownload(self, url, output):
		self._printInfo(u'Enviando requisição...')
		self.url = url
		self._fireNewFile(output)

		if 'eduk.com.br' in url:
			try:
				req = urllib2.Request(url)
				html = urllib2.urlopen(req)
			except:
				self._fireNetworkStatus(Gato.NETWORK_INTERNET_UNAVAILABLE)
				self.triedTimes = 1
				self._printError(u'Não foi possível encontrar a URL, verifique a conexão com a internet...')
				self.waitTime = (random.random()*10) + 3
				self._printInfo(u'Tentado novamente em {0}'.format(StreamRecorder.format_time(self.waitTime)))
				time.sleep(self.waitTime)
				self.startDownload(url, output)
				return

			self._printInfo('Recebido, interpretando...')
			self._fireNetworkStatus(Gato.NETWORK_INTERNET_AVAILABLE)
			# gets the link
			src = SearchResultParser(html).parse()

			if src == '':
				self._printError(u'Não foi possível encontrar o link do streaming')
				if self.maxTryTimes >= self.triedTimes:
					self.triedTimes += 1
					self.waitTime += ((random.random()*10) * self.triedTimes)
					self._printInfo('Tentado novamente em {0}'.format(StreamRecorder.format_time(self.waitTime)))
					time.sleep(self.waitTime)
					self.startDownload(url, output)
			else:
				self.triedTimes = 1
				self.waitTime = 0
				self._printInfo('Link encontrado, iniciando o download')
				self._download('http:' + src, output)
		else:
			self._printInfo('Recebido, interpretando...')
			self._fireNetworkStatus(Gato.NETWORK_INTERNET_AVAILABLE)
			self._download(url, output)


	def SetMessageHandler(self, msgHandler):
		self.msgHandler = msgHandler

	def SetNewFileHandler(self, newFileHandler):
		self.newFileHandler = newFileHandler

	def SetDownloadHandler(self, downloadHandler):
		self.downloadHandler = downloadHandler

	def SetProgressHandler(self, progressHandler):
		self.progressHandler = progressHandler

	def SetNetworkHandler(self, networkHandler):
		self.networkHandler = networkHandler

	def _printInfo(self, msg):
		if self.msgHandler != None:
			self.msgHandler(Gato.MSG_INFO, msg)
		else:
			print('[info] ' + msg)

	def _printError(self, msg):
		if self.msgHandler != None:
			self.msgHandler(Gato.MSG_ERROR, msg)
		else:
			print('[Error] ' + msg)

	def _fireNewFile(self, fileName):
		if self.newFileHandler != None:
			self.newFileHandler(fileName)

	def _downloadEvent(self, eventType, info):
		if self.downloadHandler != None:
			if eventType == StreamRecorder.DOWNLOAD_START:
				self.downloadHandler(Gato.DOWNLOAD_START, info)
			else:
				self.downloadHandler(Gato.DOWNLOAD_END, info)

	def _fireDownloadCancel(self, info):
		if self.downloadHandler != None:
			self.downloadHandler(Gato.DOWNLOAD_ERROR, info)

	def _fireNetworkStatus(self, eventType):
		if self.networkHandler != None:
			self.networkHandler(eventType)

	'''def _fireDownloadStart(self):
		if self.downloadHandler != None:
			self.downloadHandler(streamrecorder.DOWNLOAD_START)

	def _fireDownloadEnd(self):
		if self.downloadHandler != None:
			self.downloadHandler(streamrecorder.DOWNLOAD_END)

	def _fireProgressUpdate(self, msg):
		if self.progressHandler != None:
			self.progressHandler(msg)'''

def usage():
	return """
	Faz download os videos da eduk.com.br

	Para gravar o video:
	    python gato -u <url> -o <arquivo saída>

	Depois de gravar:
	    python gato -i <video> -o <arquivo saída>
	"""

def start(argv):
	url = ''
	inputfile = ''
	outputfile = ''
	convert = False
	try:
		opts, args = getopt.getopt(argv,'hi:o:u:x:')
	except getopt.GetoptError:
		print (usage())
		sys.exit(2)

	for opt, arg in opts:
		if opt == '-h':
			print (usage())
			sys.exit()
		elif opt in ("-i"):
			inputfile = arg
			convert = True
		elif opt in ("-o", "-x"):
			outputfile = arg
		elif opt in ("-u"):
			url = arg

	m = Gato()
	if convert == True:
		if inputfile == '' and outputfile == '':
			print('Argumentos incorretos.\nDigite: gato -h')
			sys.exit(1)
		m.convert(inputfile, outputfile)
	else:
		if url == '' and outputfile == '':
			print('Argumentos incorretos.\nDigite: gato -h')
			sys.exit(1)
		m.startDownload(url, outputfile)

#outPut = '/home/dk/video.flv'
#searchUrl = 'http://www.eduk.com.br/ao-vivo/554-costuras-em-encadernacao'

def main():
	parser = argparse.ArgumentParser(description='Faz download os videos da eduk.com.br')

	group = parser.add_argument_group('Para baixar o arquivo')
	group.add_argument('-u', type=str, help='URL da pagina da eduk')
	group.add_argument('-o', type=str, help='Arquivo de saída')

	group2 = parser.add_argument_group('Para converter o video baixado para mp4')
	group2.add_argument('-i', type=str, help='Arquivo de video para converção')
	group2.add_argument('-x', type=str, help='Arquivo de saída')

	args = parser.parse_args()

	start(sys.argv[1:])

#main()
